SMODS.Joker{ --Ambush
    key = "ambush",
    config = {
        extra = {
            odds = 3,
            repetitions_min = 1,
            repetitions_max = 5
        }
    },
    loc_txt = {
        ['name'] = 'Ambush',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 3{} chance to {C:attention}retrigger{} a',
            [4] = '{C:attention}scoring card{} {C:blue}1-5{} times'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true },

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
                if SMODS.pseudorandom_probability(card, 'group_0_312a8fe4', 1, card.ability.extra.odds, 'j_rolatro_ambush', false) then
              return {repetitions = pseudorandom('repetitions_d904ca75', card.ability.extra.repetitions_min, card.ability.extra.repetitions_max)}
                        
          end
        end
    end
}