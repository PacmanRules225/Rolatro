SMODS.Joker{ --Chance
    key = "chance",
    config = {
        extra = {
            ChanceMult = 1,
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'Chance',
        ['text'] = {
            [1] = '{C:green}Originated From: Forsaken{}',
            [2] = '{C:white}-{}',
            [3] = 'Every time {C:attention}Wheel of Fortune{} is',
            [4] = 'used, {C:green}1 in 2{} chance to',
            [5] = 'gain {X:mult,C:white}X0.5{} Mult',
            [6] = '{C:inactive}(Currently:{} {X:mult,C:white}X#1#{}{C:inactive} Mult){}',
            [7] = '{C:white}-{}',
            [8] = '{C:red}Cannot be modified by probability cards{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_forsaken"] = true },
    in_pool = function(self, args)
          return (
          not args 
            
          or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and G.GAME.pool_flags.rolatro_Forsaken
      end,

    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_chance') 
        return {vars = {card.ability.extra.ChanceMult, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' and context.consumeable.config.center.key == 'c_wheel_of_fortune' then
                if SMODS.pseudorandom_probability(card, 'group_0_29423ef6', 1, card.ability.extra.odds, 'j_rolatro_chance', true) then
              SMODS.calculate_effect({func = function()
                    card.ability.extra.ChanceMult = (card.ability.extra.ChanceMult) + 0.5
                    return true
                end}, card)
          end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.ChanceMult
                }
        end
    end
}