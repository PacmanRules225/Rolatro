SMODS.Joker{ --Taph
    key = "taph",
    config = {
        extra = {
            Xmult = 1.3,
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Taph',
        ['text'] = {
            [1] = '{C:green}Originated From: Forsaken{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 4{} chance to apply {C:dark_edition}Subspaced{} to a {C:attention}scoring card{}.',
            [4] = '{C:white}-{}',
            [5] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [6] = '{C:dark_edition}Subspaced{} cards give an additional {X:mult,C:white}X1.3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_forsaken"] = true, ["rolatro_modern"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["e_rolatro_subspaced"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"e_rolatro_subspaced\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_taph') 
        return {vars = {new_numerator, new_denominator}}
    end,

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if ((G.GAME.pool_flags.rolatro_Forsaken or false) and context.other_card.edition and context.other_card.edition.key == "subspaced") then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_557c522b', 1, card.ability.extra.odds, 'j_rolatro_taph', false) then
                    context.other_card:set_edition("e_rolatro_subspaced", true)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                    end
                end
            end
        end
}