SMODS.Joker{ --Builderman
    key = "builderman",
    config = {
        extra = {
            odds = 15,
            odds2 = 5,
            odds2 = 10
        }
    },
    loc_txt = {
        ['name'] = 'Builderman',
        ['text'] = {
            [1] = '{C:green}#1# in 5{} chance to add',
            [2] = '{C:attention}Builder\'s Club{} to',
            [3] = 'a {C:attention}scored playing card{}',
            [4] = '{C:white}----{}',
            [5] = '{C:green}#1# in 10{} chance to add',
            [6] = '{C:attention}Turbo Builder\'s Club{} to',
            [7] = 'a {C:attention}scored playing card{}',
            [8] = '{C:white}----{}',
            [9] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [10] = '{C:green}#1# in 15{} chance to add',
            [11] = '{C:attention}Outrageous Builder\'s Club{} to a',
            [12] = '{C:attention}scored playing card{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 16,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_forsaken"] = true, ["rolatro_legendary"] = true, ["rolatro_elevator_allowed"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_SEALS["rolatro_bc"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_bc\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local info_queue_1 = G.P_SEALS["rolatro_tbc"]
        if info_queue_1 then
            info_queue[#info_queue + 1] = info_queue_1
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_tbc\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local info_queue_2 = G.P_SEALS["rolatro_obc"]
        if info_queue_2 then
            info_queue[#info_queue + 1] = info_queue_2
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_obc\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_builderman')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_rolatro_builderman')
        local new_numerator3, new_denominator3 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds3, 'j_rolatro_builderman')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2, new_numerator3, new_denominator3}}
    end,

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (G.GAME.pool_flags.rolatro_Forsaken or false) then
                if SMODS.pseudorandom_probability(card, 'group_0_965ce365', 1, card.ability.extra.odds3, 'j_rolatro_builderman', false) then
                    context.other_card:set_seal("rolatro_obc", true)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                    end
                elseif true then
                    if SMODS.pseudorandom_probability(card, 'group_0_6dd87595', 1, card.ability.extra.odds, 'j_rolatro_builderman', false) then
                        context.other_card:set_seal("rolatro_bc", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                        end
                        if SMODS.pseudorandom_probability(card, 'group_1_f10d2f31', 1, card.ability.extra.odds2, 'j_rolatro_builderman', false) then
                            context.other_card:set_seal("rolatro_tbc", true)
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
                            end
                        end
                    end
                end
}