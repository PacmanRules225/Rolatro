SMODS.Joker{ --Noob
    key = "noob",
    config = {
        extra = {
            mult = 3,
            mult2 = 3,
            rolatro_oof = 0
        }
    },
    loc_txt = {
        ['name'] = 'Noob',
        ['text'] = {
            [1] = '{C:inactive}\"Oof!\"{}',
            [2] = '',
            [3] = '{C:mult}+3{} Mult',
            [4] = '{C:white}-{}',
            [5] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [6] = 'Additional {C:mult}+3{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_forsaken"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.pool_flags.rolatro_Forsaken or false) then
                return {
                    mult = card.ability.extra.mult
                }
            else
                play_sound("rolatro_oof")
    SMODS.calculate_effect({message = "OOF!"}, card)
                return {
                    mult = card.ability.extra.mult2
                }
            end
        end
    end
}