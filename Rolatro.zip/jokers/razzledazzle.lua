SMODS.Joker{ --Razzle & Dazzle
    key = "razzledazzle",
    config = {
        extra = {
            mult = 5,
            chips = 20
        }
    },
    loc_txt = {
        ['name'] = 'Razzle & Dazzle',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+5{} Mult on {C:attention}odd{} scoring cards',
            [4] = '{C:chips}+20{} Chips on {C:attention}even{} scoring cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 14 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 9) then
                return {
                    mult = card.ability.extra.mult
                }
            elseif (context.other_card:get_id() == 2 or context.other_card:get_id() == 4 or context.other_card:get_id() == 6 or context.other_card:get_id() == 8 or context.other_card:get_id() == 10) then
                return {
                    chips = card.ability.extra.chips
                }
            end
        end
    end
}