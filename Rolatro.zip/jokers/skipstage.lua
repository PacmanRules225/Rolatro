SMODS.Joker{ --Skip Stage
    key = "skipstage",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Skip Stage',
        ['text'] = {
            [1] = '{C:green}Originated From: Quite literally every obby game{}',
            [2] = '{C:white}-{}',
            [3] = 'Instantly {C:green}win{} the current blind when {C:attention}sold{}!'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 40,
    rarity = 4,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_legendary"] = true },

    calculate = function(self, card, context)
        if context.selling_self  then
                G.E_MANAGER:add_event(Event({
    blocking = false,
    func = function()
        if G.STATE == G.STATES.SELECTING_HAND then
            G.GAME.chips = G.GAME.blind.chips
            G.STATE = G.STATES.HAND_PLAYED
            G.STATE_COMPLETE = true
            end_round()
            return true
        end
    end
}))
                return {
                    message = "Win!"
                }
        end
    end
}