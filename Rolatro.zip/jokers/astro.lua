SMODS.Joker{ --Astro
    key = "astro",
    config = {
        extra = {
            MoonMult = 0,
            planetcardsused = 0
        }
    },
    loc_txt = {
        ['name'] = 'Astro',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+3{} Mult for every {C:planet}Planet Card{} used this run.',
            [4] = '{C:mult}+12{} Mult for every time {C:tarot}The Moon{} is used this run.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.using_consumeable  and not context.blueprint then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' and context.consumeable.config.center.key == 'c_moon' then
                return {
                    func = function()
                        card.ability.extra.MoonMult = (card.ability.extra.MoonMult) + 12
                        return true
                        end
                    }
                end
            end
            if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = ((G.GAME.consumeable_usage_total and G.GAME.consumeable_usage_total.planet or 0)) * 3,
                    extra = {
                    mult = card.ability.extra.MoonMult
                }
            }
        end
    end
}