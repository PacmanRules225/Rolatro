SMODS.Joker{ --Zombie
    key = "zombie",
    config = {
        extra = {
            zombiechips = 0,
            odds = 10
        }
    },
    loc_txt = {
        ['name'] = 'Zombie',
        ['text'] = {
            [1] = '{C:chips}+#1#{} Chips',
            [2] = '{C:green}1 in 10{} chance to {C:attention}destroy{}',
            [3] = 'a playing card that\'s being played.',
            [4] = 'Gains {C:blue}+10{} Chips if {C:green}succeeded{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_innovationinc"] = true, ["rolatro_elevator_allowed"] = true, ["rolatro_mansion"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["e_rolatro_zombified"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"e_rolatro_zombified\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_zombie') 
        return {vars = {card.ability.extra.zombiechips, new_numerator, new_denominator}}
    end,

    
    calculate = function(self, card, context)
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_f33fdf16', 1, card.ability.extra.odds, 'j_rolatro_zombie', false) then
                    card.ability.extra.zombiechips = (card.ability.extra.zombiechips) + 10
                    
                end
                if SMODS.pseudorandom_probability(card, 'group_1_f33fdf16', 1, card.ability.extra.odds, 'j_rolatro_zombie', false) then
                    context.other_card.should_destroy = true
                    card.ability.extra.zombiechips = (card.ability.extra.zombiechips) + 10
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
            end
        end
    end
}