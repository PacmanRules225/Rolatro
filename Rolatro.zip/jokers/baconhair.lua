SMODS.Joker{ --Bacon Hair
    key = "baconhair",
    config = {
        extra = {
            baconcoin = 0,
            chips = 20
        }
    },
    loc_txt = {
        ['name'] = 'Bacon Hair',
        ['text'] = {
            [1] = '{C:chips}+20{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
                return {
                    chips = card.ability.extra.chips
                }
        end
    end
}