SMODS.Joker{ --c00lkidd
    key = "c00lkidd",
    config = {
        extra = {
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'c00lkidd',
        ['text'] = {
            [1] = '{C:inactive}\"team c00lkidd join today!\"{}',
            [2] = '',
            [3] = 'When a hand is played,',
            [4] = '{C:green}1 in 5{} chance to add a {C:red}c00l Seal{}',
            [5] = 'to a {C:attention}card{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_c00l",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_myth"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_c070bb15', 1, card.ability.extra.odds, 'j_rolatro_c00lkidd', false) then
              context.other_card:set_seal("rolatro_c00lseal", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "c00l!", colour = G.C.BLUE})
          end
            end
        end
    end
}