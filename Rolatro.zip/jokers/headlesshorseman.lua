SMODS.Joker{ --Headless Horseman
    key = "headlesshorseman",
    config = {
        extra = {
            cardsindiscard = 0
        }
    },
    loc_txt = {
        ['name'] = 'Headless Horseman',
        ['text'] = {
            [1] = '{C:red}+1{} Mult for {C:attention}every card{} in the {C:red}discard{} pile',
            [2] = '{C:inactive}(Currently:{} {C:red}+#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 13,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_retro"] = true, ["rolatro_legendary"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {#(G.discard and G.discard.cards or {})}}
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = #(G.discard and G.discard.cards or {})
            }
        end
    end
}