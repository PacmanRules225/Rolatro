SMODS.Joker{ --Boxten
    key = "boxten",
    config = {
        extra = {
            BoxMult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Boxten',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+#1#{} Mult',
            [4] = '{C:mult}+1{} Mult is added every time',
            [5] = 'the {C:attention}music{} changes while in',
            [6] = 'the run',
            [7] = '{C:inactive}(excluding modded Jokers that change{}',
            [8] = '{C:inactive}the music){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.BoxMult}}
    end,

    
    calculate = function(self, card, context)
        if context.setting_blind  and not context.blueprint then
            if G.GAME.blind.boss then
                return {
                    func = function()
                        card.ability.extra.BoxMult = (card.ability.extra.BoxMult) + 1
                        return true
                        end
                    }
                end
            end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  and not context.blueprint then
            return {
                func = function()
                    card.ability.extra.BoxMult = (card.ability.extra.BoxMult) + 1
                    return true
                    end
                }
            end
            if context.starting_shop  and not context.blueprint then
                return {
                    func = function()
                        card.ability.extra.BoxMult = (card.ability.extra.BoxMult) + 1
                        return true
                        end
                    }
                end
                if context.open_booster  and not context.blueprint then
                    return {
                        func = function()
                            card.ability.extra.BoxMult = (card.ability.extra.BoxMult) + 1
                            return true
                            end
                        }
                    end
                if context.ending_shop  and not context.blueprint then
                    return {
                        func = function()
                            card.ability.extra.BoxMult = (card.ability.extra.BoxMult) + 1
                            return true
                            end
                        }
                    end
                    if context.cardarea == G.jokers and context.joker_main  then
                        return {
                            mult = card.ability.extra.BoxMult
                        }
                    end
                end
}