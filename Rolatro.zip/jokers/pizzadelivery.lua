SMODS.Joker{ --Pizza Delivery
    key = "pizzadelivery",
    config = {
        extra = {
            odds = 8,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Pizza Delivery',
        ['text'] = {
            [1] = '{C:green}Originated From: Work at a Pizza Place{}',
            [2] = '{C:white}-{}',
            [3] = 'When hand is played, {C:green}1 in 8{} chance to',
            [4] = 'spawn a {C:red}Pepperoni Pizza{}',
            [5] = '{C:inactive}(must have room){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_elevator_allowed"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["c_rolatro_pizza"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"c_rolatro_pizza\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_pizzadelivery') 
        return {vars = {new_numerator, new_denominator}}
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_12148ab0', 1, card.ability.extra.odds, 'j_rolatro_pizzadelivery', false) then
                    for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
                        G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.4,
                        func = function()
                            play_sound('timpani')
                            SMODS.add_card({ set = 'gear', key = 'c_rolatro_pizza'})                            
                            card:juice_up(0.3, 0.5)
                            return true
                            end
                        }))
                    end
                    delay(0.6)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and localize('k_plus_consumable') or nil, colour = G.C.PURPLE})
                end
            end
        end
    end
}