SMODS.Joker{ --Pizza Delivery
    key = "pizzadelivery",
    config = {
        extra = {
            odds = 8,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Pizza Delivery',
        ['text'] = {
            [1] = '{C:green}Originated From: Work at a Pizza Place{}',
            [2] = '',
            [3] = '{C:green}1 in 8{} chance to spawn a',
            [4] = '{C:red}Pepperoni Pizza{}.',
            [5] = '{C:inactive}(must have room){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_12148ab0', 1, card.ability.extra.odds, 'j_rolatro_pizzadelivery', false) then
              local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'gear', key = 'c_rolatro_pizza', edition = 'e_negative', soulable = undefined, key_append = 'joker_forge_gear'}
                        return true
                    end
                }))
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = created_consumable and localize('k_plus_consumable') or nil, colour = G.C.PURPLE})
          end
            end
        end
    end
}