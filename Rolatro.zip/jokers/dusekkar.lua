SMODS.Joker{ --Dusekkar
    key = "dusekkar",
    config = {
        extra = {
            xchips = 2,
            echips = 2
        }
    },
    loc_txt = {
        ['name'] = 'Dusekkar',
        ['text'] = {
            [1] = '{X:chips,C:white}X2{} Chips on {C:attention}last hand{}',
            [2] = '{C:white}-{}',
            [3] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [4] = '{X:chips,C:white}^2{} Chips on {C:attention}last hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.current_round.hands_left < 1 and not ((G.GAME.pool_flags.rolatro_Forsaken or false))) then
                return {
                    x_chips = card.ability.extra.xchips
                }
            elseif (G.GAME.current_round.hands_left < 1 and (G.GAME.pool_flags.rolatro_Forsaken or false)) then
                return {
                    e_chips = card.ability.extra.echips
                }
            end
        end
    end
}