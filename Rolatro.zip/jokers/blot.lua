SMODS.Joker{ --Blot
    key = "blot",
    config = {
        extra = {
            chips_min = 1,
            chips_max = 500
        }
    },
    loc_txt = {
        ['name'] = 'Blot',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:chips}spihC{} fo tnuoma {C:attention}modnar{} a seviG',
            [4] = '{C:inactive})005-1+({}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 4,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = pseudorandom('chips_e44f8841', card.ability.extra.chips_min, card.ability.extra.chips_max)
            }
        end
    end
}