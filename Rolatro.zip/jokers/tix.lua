SMODS.Joker{ --Tix
    key = "tix",
    config = {
        extra = {
            tix = 0,
            sell_value = 0,
            sell_value2 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Tix',
        ['text'] = {
            [1] = '{C:red}ATTENTION: This Joker is bugged and',
            [2] = 'crashes the game. If you somehow',
            [3] = 'see this, do NOT use it.{}',
            [4] = '{C:white}-{}',
            [5] = '{C:inactive}Original Description:{}',
            [6] = 'At the end of every round, gain {C:attention}10{} Tix.',
            [7] = 'Sell this Joker to convert',
            [8] = 'the earned Tix to {C:attention}Money{}.',
            [9] = '{C:inactive}(10 Tix >{} {C:money}$1{}{C:inactive}){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = false,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'uta' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.buying_card and context.card.config.center.key == self.key and context.cardarea == G.jokers  and not context.blueprint then
                return {
                    func = function()local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        local target_card = G.jokers.cards[my_post]for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = card.ability.extra.sell_value
            target_joker:set_cost()
            end
        end
                    return true
                end,
                    message = "Sell Value: $"..tostring(card.ability.extra.sell_value)
                }
        end
        if context.starting_shop  then
                return {
                    func = function()local my_pos = nil
        for i = 1, #G.jokers.cards do
            if G.jokers.cards[i] == card then
                my_pos = i
                break
            end
        end
        local target_card = G.jokers.cards[my_post]for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value2
            target_joker:set_cost()
            end
        end
                    return true
                end,
                    message = "+10 Tix"
                }
        end
    end
}