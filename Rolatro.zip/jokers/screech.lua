SMODS.Joker{ --Screech
    key = "screech",
    config = {
        extra = {
            screeched = 0,
            odds = 4,
            mult = 6,
            rolatro_screech_pst = 0,
            explode = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Screech',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 2{} chance to {C:attention}add{} {C:mult}+6{} Mult before',
            [4] = '{C:red}self destructing{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true, ["rolatro_elevator_allowed"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_8b0e725e', 1, card.ability.extra.odds, 'j_rolatro_screech', false) then
                    G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("rolatro_screech_pst")
                        
                        return true
                        end,
                    }))
                    card.ability.extra.screeched = 1
                        SMODS.calculate_effect({mult = card.ability.extra.mult}, card)
                    end
                end
            end
            if context.after and context.cardarea == G.jokers  and not context.blueprint then
                if (card.ability.extra.screeched or 0) == 1 then
                    return {
                        func = function()
                            card:explode()
                            return true
                            end,
                            extra = {
                            func = function()
                                card.ability.extra.screeched = 0
                                return true
                                end,
                                colour = G.C.BLUE
                            }
                        }
                    end
                end
            end
}