SMODS.Joker{ --Rodger
    key = "rodger",
    config = {
        extra = {
            xchips = 2,
            Xmult = 2
        }
    },
    loc_txt = {
        ['name'] = 'Rodger',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = 'During {C:attention}boss blinds{}, {X:chips,C:white}X2{} Chips and',
            [4] = '{X:mult,C:white}X2{} Mult when {C:attention}hand played{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.blind.boss then
                return {
                    x_chips = card.ability.extra.xchips,
                    extra = {
                    Xmult = card.ability.extra.Xmult
                }
            }
        end
    end
end
}