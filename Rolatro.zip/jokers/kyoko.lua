SMODS.Joker{ --Kyoko
    key = "kyoko",
    config = {
        extra = {
            mult = 6,
            mult2 = 6,
            mult3 = 6,
            mult4 = 6
        }
    },
    loc_txt = {
        ['name'] = 'Kyoko',
        ['text'] = {
            [1] = '{C:green}Originated From: Block Tales{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+6{} Mult if any of the following',
            [4] = '{C:attention}Jokers{} are in hand: {C:attention}Hiker{}, {C:attention}Campfire{},',
            [5] = '{C:attention}Hit the Road{}, {C:attention}Ride the Bus{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_modern"] = true, ["rolatro_blocktales"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_hit_the_road" then
              return true
          end
      end
      return false
  end)() then
                return {
                    mult = card.ability.extra.mult
                }
            elseif (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_hiker" then
              return true
          end
      end
      return false
  end)() then
                return {
                    mult = card.ability.extra.mult2
                }
            elseif (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_campfire" then
              return true
          end
      end
      return false
  end)() then
                return {
                    mult = card.ability.extra.mult3
                }
            elseif (function()
      for i = 1, #G.jokers.cards do
          if G.jokers.cards[i].config.center.key == "j_ride_the_bus" then
              return true
          end
      end
      return false
  end)() then
                return {
                    mult = card.ability.extra.mult4
                }
            end
        end
    end
}