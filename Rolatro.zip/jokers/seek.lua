SMODS.Joker{ --Seek
    key = "seek",
    config = {
        extra = {
            odds = 20
        }
    },
    loc_txt = {
        ['name'] = 'Seek',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 20{} chance to add a {C:attention}Seek seal{} to',
            [4] = 'a {C:attention}scoring card{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_SEALS["rolatro_seek"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_seek\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_seek') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_bad894b6', 1, card.ability.extra.odds, 'j_rolatro_seek', false) then
              context.other_card:set_seal("rolatro_seek", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
    end
}