SMODS.Joker{ --Cashier (Pizza Place)
    key = "cashierpizzaplace",
    config = {
        extra = {
            odds = 4,
            n = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cashier (Pizza Place)',
        ['text'] = {
            [1] = '{C:green}Originated From: Work at a Pizza Place{}',
            [2] = '{C:white}-{}',
            [3] = 'When {C:tarot}Wheel of Fortune{} is used, {C:green}1 in 4{} chance',
            [4] = 'to spawn a {C:dark_edition}Negative{} {C:red}Pepperoni Pizza{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_retro"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["c_wheel_of_fortune"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"c_wheel_of_fortune\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local info_queue_1 = G.P_CENTERS["c_rolatro_pizza"]
        if info_queue_1 then
            info_queue[#info_queue + 1] = info_queue_1
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"c_rolatro_pizza\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_cashierpizzaplace') 
        return {vars = {new_numerator, new_denominator}}
    end,

    
    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Tarot' and context.consumeable.config.center.key == 'c_wheel_of_fortune' then
                if SMODS.pseudorandom_probability(card, 'group_0_4e911146', 1, card.ability.extra.odds, 'j_rolatro_cashierpizzaplace', false) then
                        SMODS.calculate_effect({func = function()
                            
                            for i = 1, 1 do
                                G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
                                        G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                                    end
                                    
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'gear', edition = 'e_negative', key = 'c_rolatro_pizza'})                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                    end
                                }))
                            end
                            delay(0.6)
                            
                            if created_consumable then
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
                            end
                            return true
                            end}, card)
                        end
                    end
                end
            end
}