SMODS.Joker{ --Linked Sword
    key = "linked_sword",
    config = {
        extra = {
            odds = 10,
            Xmult = 1.5,
            rolatro_swordlunge = 0
        }
    },
    loc_txt = {
        ['name'] = 'Linked Sword',
        ['text'] = {
            [1] = '{C:inactive}\"With blood and iron.\"{}',
            [2] = '',
            [3] = '',
            [4] = '{C:green}1 in 10{} chance to {C:attention}Lunge{} and score {X:mult,C:white}X1.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_brickbattle"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d23c0750', 1, card.ability.extra.odds, 'j_rolatro_linked_sword', false) then
              play_sound("rolatro_swordlunge")
                        SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
          end
            end
        end
    end
}