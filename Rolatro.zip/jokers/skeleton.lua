SMODS.Joker{ --Skeleton
    key = "skeleton",
    config = {
        extra = {
            shatter = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Skeleton',
        ['text'] = {
            [1] = 'Prevents Death if Chips scored',
            [2] = 'are at least {C:attention}50%{} of required Chips',
            [3] = '{C:red}self destructs{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_retro"] = true, ["rolatro_mansion"] = true },

    
    calculate = function(self, card, context)
    if context.end_of_round and context.game_over and context.main_eval  and not context.blueprint then
        if G.GAME.chips / G.GAME.blind.chips >= to_big(0.5) then
            return {
                saved = true,
                message = localize('k_saved_ex'),
                extra = {
                func = function()
                    card:shatter()
                    return true
                    end,
                    colour = G.C.RED
                }
            }
        end
    end
end
}