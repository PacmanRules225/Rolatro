SMODS.Joker{ --Dummy (GASA4)
    key = "dummygasa4",
    config = {
        extra = {
            DummySlots = 0,
            ceil = 0
        }
    },
    loc_txt = {
        ['name'] = 'Dummy (GASA4)',
        ['text'] = {
            [1] = '{C:green}Originated From: get a snack at 4 am{}',
            [2] = '{C:white}-{}',
            [3] = '{C:purple}+??{} Hand Size',
            [4] = 'Hand size {C:attention}changes every round{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 14,
    rarity = "rolatro_bloxxer",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_getasnack"] = true, ["rolatro_modern"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  and not context.blueprint then
            return {
                func = function()
                    card.ability.extra.DummySlots = math.ceil(card.ability.extra.DummySlots)
                    return true
                    end,
                    extra = {
                    func = function()
                        local current_hand_size = G.hand.config.card_limit
                        local target_hand_size = card.ability.extra.DummySlots
                        local difference = target_hand_size - current_hand_size
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Hand Size set to "..tostring(card.ability.extra.DummySlots), colour = G.C.BLUE})
                            G.hand:change_size(difference)
                                return true
                                end,
                                colour = G.C.BLUE
                            }
                        }
                    end
                if context.ending_shop  and not context.blueprint then
                    return {
                        func = function()
                            card.ability.extra.DummySlots = pseudorandom('DummySlots_b0562a80', 4.8, 10)
                            return true
                            end
                        }
                    end
                end
}