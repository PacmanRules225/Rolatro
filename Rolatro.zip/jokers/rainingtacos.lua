SMODS.Joker{ --Raining Tacos
    key = "rainingtacos",
    config = {
        extra = {
            rolatro_rainingtacos = 0,
            n = 0,
            y = 0
        }
    },
    loc_txt = {
        ['name'] = 'Raining Tacos',
        ['text'] = {
            [1] = '{C:inactive}\"No need to ask why!\"{}',
            [2] = 'Get a {C:dark_edition}Negative{} {C:attention}Taco{} {C:red}Gear{} at the start',
            [3] = 'of every blind.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_retro"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_CENTERS["c_rolatro_taco"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"c_rolatro_taco\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local info_queue_1 = G.P_CENTERS["e_negative"]
        if info_queue_1 then
            info_queue[#info_queue + 1] = info_queue_1
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"e_negative\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        return {vars = {}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                play_sound("rolatro_rainingtacos")
    SMODS.calculate_effect({message = "Its Raining Tacos!"}, card)
                return {
                    func = function()
      
    for i = 1, 1 do
            G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
            if G.consumeables.config.card_limit > #G.consumeables.cards + G.GAME.consumeable_buffer then
              G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
            end

            play_sound('timpani')
            SMODS.add_card({ set = 'gear', edition = 'e_negative', key = 'c_rolatro_taco'})                            
            card:juice_up(0.3, 0.5)
            return true
        end
        }))
    end
    delay(0.6)

                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
                    end
                    return true
                  end
                }
        end
    end
}