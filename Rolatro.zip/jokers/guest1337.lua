SMODS.Joker{ --Guest 1337
    key = "guest1337",
    config = {
        extra = {
            LastGuestMult = 6
        }
    },
    loc_txt = {
        ['name'] = 'Guest 1337',
        ['text'] = {
            [1] = '{C:green}Originated From: The Last Guest{}',
            [2] = '{C:white}-{}',
            [3] = '{C:inactive}\"Be strong. Always be strong.\"{}',
            [4] = '{C:mult}+#1#{} Mult',
            [5] = 'Gains {C:mult}+2{} Mult for every card',
            [6] = '{C:attention}destroyed{}',
            [7] = '{C:red}Resets to 6 after every Boss Blind{}',
            [8] = '{C:white}-{}',
            [9] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [10] = '{C:red}No longer resets after every Boss Blind{} and',
            [11] = 'will instead{C:attention} reset after you are saved from{}',
            [12] = '{C:attention}death{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 11,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_modern"] = true, ["rolatro_forsaken"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.LastGuestMult}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.LastGuestMult
                }
        end
        if context.remove_playing_cards  then
                return {
                    func = function()
                    card.ability.extra.LastGuestMult = (card.ability.extra.LastGuestMult) + 2
                    return true
                end
                }
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if not ((G.GAME.pool_flags.rolatro_Forsaken or false)) then
                return {
                    func = function()
                    card.ability.extra.LastGuestMult = 6
                    return true
                end,
                    message = "Reset!"
                }
            end
        end
        if context.end_of_round and context.game_over and context.main_eval  then
            if (G.GAME.pool_flags.rolatro_Forsaken or false) then
                return {
                    func = function()
                    card.ability.extra.LastGuestMult = 6
                    return true
                end,
                    message = "Reset!"
                }
            end
        end
    end
}