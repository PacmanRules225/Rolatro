SMODS.Joker{ --HUGE Joker Pet
    key = "hugejokerpet",
    config = {
        extra = {
            Xmult = 10
        }
    },
    loc_txt = {
        ['name'] = 'HUGE Joker Pet',
        ['text'] = {
            [1] = '{X:mult,C:white}X10{} Mult',
            [2] = 'Can only be obtained via the',
            [3] = '{C:attention}Pet Simulator 99{} {C:blue}Experience{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 2
    },
    display_size = {
        w = 71 * 1.25, 
        h = 95 * 1.25
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' and args.source ~= 'sou' 
          or args.source == 'rif' or args.source == 'rta' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult
                }
        end
    end
}