SMODS.Joker{ --Cashier (GASA4)
    key = "cashier",
    config = {
        extra = {
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'Cashier (GASA4)',
        ['text'] = {
            [1] = '{C:green}Originated From: get a snack at 4 am{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 5{} chance to create a {C:rare}Rare Tag{}',
            [4] = 'when you {C:attention}enter the shop{}',
            [5] = '{C:white}-{}',
            [6] = '{C:red}Cannot be modified by probability cards{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_modern"] = true, ["rolatro_getasnack"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_TAGS["tag_rare"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"tag_rare\" isn't a valid Tag key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_cashier') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.starting_shop  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d61c85e9', 1, card.ability.extra.odds, 'j_rolatro_cashier', true) then
              SMODS.calculate_effect({func = function()
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_rare")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
                    return true
                end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Created Tag!", colour = G.C.GREEN})
          end
            end
        end
    end
}