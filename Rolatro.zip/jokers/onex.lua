SMODS.Joker{ --1x1x1x1
    key = "onex",
    config = {
        extra = {
            odds = 4,
            xchips = 0,
            Xmult = 0
        }
    },
    loc_txt = {
        ['name'] = '1x1x1x1',
        ['text'] = {
            [1] = '{C:gold}Exclusive to: 1x1x1x1 Attacks{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 4{} chance to {C:red}nullify{} all {X:chips,C:white}Chips{} and {X:mult,C:white}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "rolatro_exclusive",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true },

    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_99051a19', 1, card.ability.extra.odds, 'j_rolatro_onex', true) then
                        SMODS.calculate_effect({x_chips = card.ability.extra.xchips}, card)
                            SMODS.calculate_effect({Xmult = card.ability.extra.Xmult}, card)
                        end
                    end
                end
            end
}