SMODS.Joker{ --Server Maintenance
    key = "servermaintenance",
    config = {
        extra = {
            repetitions = 75,
            Xmult = 2,
            odds = 10,
            maintenance = 0,
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Server Maintenance',
        ['text'] = {
            [1] = '{C:blue}Based On: The 2021 Roblox Outage{}',
            [2] = '{C:white}-{}',
            [3] = '{C:inactive}\"We\'re making things more awesome.{}',
            [4] = '{C:inactive}Be back soon.\"{}',
            [5] = '{X:mult,C:white}X2{} Mult',
            [6] = '{C:green}1 in 10{} chance to sit through a {C:attention}lengthy break{}',
            [7] = '{C:inactive}(which depends on your game speed){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_modern"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.pool_flags.rolatro_maintenance or false) then
                for i = 1, card.ability.extra.repetitions do
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Maintenance!", colour = G.C.BLACK})
                end
            else
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.before and context.cardarea == G.jokers  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_26927d14', 1, card.ability.extra.odds, 'j_rolatro_servermaintenance', false) then
                    G.GAME.pool_flags.rolatro_maintenance = true
                    
                end
            end
        end
        if context.after and context.cardarea == G.jokers  and not context.blueprint then
            G.GAME.pool_flags.rolatro_maintenance = false
        end
    end
}