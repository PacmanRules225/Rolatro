SMODS.Joker{ --Shedletsky
    key = "shedletsky",
    config = {
        extra = {
            odds = 10,
            n = 0,
            start_dissolve = 0
        }
    },
    loc_txt = {
        ['name'] = 'Shedletsky',
        ['text'] = {
            [1] = '{C:inactive}\"Blame John.\"{}',
            [2] = '',
            [3] = '{C:green}1 in 10{} chance to {C:attention}disable the next boss{}',
            [4] = '{C:attention}blind{} before {C:red}self destructing{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "rolatro_epic",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_forsaken"] = true },

    calculate = function(self, card, context)
        if context.setting_blind  and not context.blueprint then
            if G.GAME.blind.boss then
                if SMODS.pseudorandom_probability(card, 'group_0_b6e99062', 1, card.ability.extra.odds, 'j_rolatro_shedletsky', false) then
              SMODS.calculate_effect({func = function()
            if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.blind:disable()
                        play_sound('timpani')
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
            end
                    return true
                end}, card)
                        SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
          end
            end
        end
    end
}