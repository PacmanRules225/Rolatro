SMODS.Joker{ --Guest
    key = "guest",
    config = {
        extra = {
            guestchips = 0
        }
    },
    loc_txt = {
        ['name'] = 'Guest',
        ['text'] = {
            [1] = '{C:inactive}\"Make a free account to change how you look!\"{}',
            [2] = '',
            [3] = '{C:chips}+7{} Chips for every {C:attention}High Card{} played this run.',
            [4] = '{C:inactive}(Current:{} {C:chips}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_elevator_allowed"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.guestchips}}
    end,

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = card.ability.extra.guestchips
            }
        end
        if context.before and context.cardarea == G.jokers  then
            if context.scoring_name == "High Card" then
                return {
                    func = function()
                        card.ability.extra.guestchips = (card.ability.extra.guestchips) + 7
                        return true
                        end,
                        message = "+7 Chips"
                    }
                end
            end
        end
}