SMODS.Joker{ --Shrimpo
    key = "shrimpo",
    config = {
        extra = {
            Xmult = 2.5,
            Xmult2 = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Shrimpo',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{X:mult,C:white}X2.5{} Mult when the Boss Blind is {C:attention}triggered{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.blind.triggered then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "I HATE BOSS BLINDS!"
                }
            elseif (G.GAME.blind.config.blind.key == "bl_wall" or G.GAME.blind.config.blind.key == "bl_water" or G.GAME.blind.config.blind.key == "bl_manacle" and G.GAME.blind.config.blind.key == "bl_needle" and G.GAME.blind.config.blind.key == "bl_mark" and G.GAME.blind.config.blind.key == "bl_final_vessel" and G.GAME.blind.config.blind.key == "bl_final_bell") then
                return {
                    Xmult = card.ability.extra.Xmult2
                }
            end
        end
    end
}