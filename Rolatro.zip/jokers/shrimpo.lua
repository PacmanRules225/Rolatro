SMODS.Joker{ --Shrimpo
    key = "shrimpo",
    config = {
        extra = {
            HateMult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Shrimpo',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = 'Gain {X:mult,C:white}X2.5{} Mult when the Boss Blind is {C:attention}triggered{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.blind.triggered then
                card.ability.extra.HateMult = (card.ability.extra.HateMult) + 2.5
            elseif (G.GAME.blind.config.blind.key == "bl_wall" or G.GAME.blind.config.blind.key == "bl_water" or G.GAME.blind.config.blind.key == "bl_manacle" and G.GAME.blind.config.blind.key == "bl_needle" and G.GAME.blind.config.blind.key == "bl_mark" and G.GAME.blind.config.blind.key == "bl_final_vessel" and G.GAME.blind.config.blind.key == "bl_final_bell") then
                card.ability.extra.HateMult = (card.ability.extra.HateMult) + 2.5
            else
                return {
                    x_chips = card.ability.extra.HateMult
                }
            end
        end
    end
}