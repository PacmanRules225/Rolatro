SMODS.Joker{ --Disconnection Error
    key = "disconnectionerror",
    config = {
        extra = {
            xchips = 2.5,
            odds = 6
        }
    },
    loc_txt = {
        ['name'] = 'Disconnection Error',
        ['text'] = {
            [1] = '{C:inactive}Please check your internet connection{}',
            [2] = '{C:inactive}and try again.{}',
            [3] = '{C:white}-{}',
            [4] = '{X:mult,C:white}X2.5{} Mult',
            [5] = '{C:green}1 in 6{} chance to {C:red}disconnect{} from the game',
            [6] = '{C:red}(intentional game crash){}',
            [7] = '{C:white}-{}',
            [8] = '{C:red}Cannot be modified by probability cards or{}',
            [9] = '{C:red}copied by certain Jokers such as Blueprint{}',
            [10] = '{C:red}and Brainstorm{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_retro"] = true, ["rolatro_modern"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if true then
                return {
                    x_chips = card.ability.extra.xchips
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_813a3a2f', 1, card.ability.extra.odds, 'j_rolatro_disconnectionerror', true) then
                            error("Please check your internet connection and try again. (Error Code: 277) | INTENTIONAL CRASH")
                            
                        end
                        return true
                        end
                    }
                end
            end
        end
}