SMODS.Joker{ --Dupe
    key = "dupe",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Dupe',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = 'Spawns a random playing card with {C:attention}Chat Filter Seal{} in {C:attention}deck{}',
            [4] = 'at the start of {C:attention}every blind{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true },

    
    calculate = function(self, card, context)
        if context.setting_blind  then
            local card_front = pseudorandom_element(G.P_CARDS, pseudoseed('add_card_hand'))
            local new_card = create_playing_card({
            front = card_front,
            center = 
            G.P_CENTERS.c_base
        }, G.discard, true, false, nil, true)
        new_card:set_seal("rolatro_chatfilter", true)
        
        G.E_MANAGER:add_event(Event({
        func = function()
            new_card:start_materialize()
            G.play:emplace(new_card)
            return true
            end
        }))
        return {
            func = function()
                G.E_MANAGER:add_event(Event({
                func = function()
                    G.deck.config.card_limit = G.deck.config.card_limit + 1
                    return true
                    end
                }))
                draw_card(G.play, G.deck, 90, 'up')
                    SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                end,
                message = "Added Card!"
            }
        end
    end
}