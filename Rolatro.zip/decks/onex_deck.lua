SMODS.Back {
    key = 'onex_deck',
    pos = { x = 1, y = 0 },
    config = {
      ante_win_value = 8,
        voucher_slots_value = 1,
        booster_slots_value = 1,
        joker_slots_value = 1,
},
    loc_txt = {
        name = '1x1x1x1 Attacks',
        text = {
            [1] = 'All {C:attention}starting cards{} are {C:dark_edition}Hacked{}.',
            [2] = 'Start with {X:black,C:green}1x1x1x1{}.',
            [3] = '{C:red}Only 1{} booster pack in {C:attention}shop.{}',
            [4] = '{C:red}No vouchers can spawn.{}',
            [5] = 'You start with a random {C:legendary}Legendary{} {C:attention}Joker{}.',
            [6] = 'You start with {C:money}$10.{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.E_MANAGER:add_event(Event({
                  func = function()
                      play_sound('timpani')
                      if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                          G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_onex' })
                          new_joker:add_sticker('eternal', true)
                          G.GAME.joker_buffer = 0
                      end
                      return true
                  end
              }))
            G.E_MANAGER:add_event(Event({
                  func = function()
                      play_sound('timpani')
                      if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                          G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                      local new_joker = SMODS.add_card({ set = 'Joker', rarity = 'Legendary' })
                          G.GAME.joker_buffer = 0
                      end
                      return true
                  end
              }))
            G.E_MANAGER:add_event(Event({
                    func = function()
                    for k, v in pairs(G.playing_cards) do
                        v:set_edition( "e_rolatro_hacked", true, true, true)
                    end
                    return true
                end
            }))
            G.GAME.starting_params.dollars = 10
            G.GAME.win_ante = 8
            
            
        G.GAME.starting_params.vouchers_in_shop = 1
        
            
        G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    local current_booster_slots = (G.GAME.modifiers.extra_boosters or 0)
                    local target_booster_slots = 1
                    local difference = target_booster_slots - current_booster_slots
                    SMODS.change_booster_limit(difference)
                    return true
                end
            }))
        
            
        G.GAME.starting_params.joker_slots = G.GAME.starting_params.joker_slots + 1
    end
}