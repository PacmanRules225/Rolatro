SMODS.Back {
    key = 'c00l_deck',
    pos = { x = 3, y = 0 },
    config = {
},
    loc_txt = {
        name = 'c00l Deck',
        text = {
            [1] = 'Start with an {C:attention}Eternal{} {C:dark_edition}Negative{} {C:red}c00lkidd{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.E_MANAGER:add_event(Event({
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_c00lkidd' })
                          new_joker:set_edition("e_negative", true)
                          new_joker:add_sticker('eternal', true)
                      return true
                  end
              }))
    end
}