SMODS.Back {
    key = 'deckfornoobs',
    pos = { x = 0, y = 0 },
    config = {
      ante_win_value = 4,
        hands_value = 1,
        discards_value = 1,
        item_rate = 2,
        voucher_slots_value = 2,
},
    loc_txt = {
        name = 'Deck for Noobs',
        text = {
            [1] = '{C:red}Gears{} and {C:blue}Experiences{} appear {C:green}2x{} more often.',
            [2] = '{C:blue}+1{} hand, {C:red}+1{} discard.',
            [3] = '{C:attention}+2{} Consumable Slots',
            [4] = 'Beat {C:attention}Ante 4{} to win.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
            G.GAME.starting_params.discards = G.GAME.starting_params.discards + 1
            G.GAME.starting_params.dollars = G.GAME.starting_params.dollars +8
            G.GAME.win_ante = 4
            
            
        G.GAME.experience_rate = G.GAME.experience_rate +2
        
            
        G.GAME.gear_rate = G.GAME.gear_rate +2
        
            
        G.GAME.starting_params.consumable_slots = G.GAME.starting_params.consumable_slots + 2
    end
}