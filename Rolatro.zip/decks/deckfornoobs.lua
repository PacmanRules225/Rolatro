SMODS.Back {
    key = 'deckfornoobs',
    pos = { x = 0, y = 0 },
    config = {
      ante_win_value = 4,
        hands_value = 1,
        discards_value = 1,
        item_rate = 2,
        voucher_slots_value = 2,
        odds = 5,
},
    loc_txt = {
        name = 'Deck for Noobs',
        text = {
            [1] = 'Start with {C:tarot}New User{} and {C:money}$8{}.',
            [2] = '{C:green}1 in 5{} chance to also start with {C:tarot}Alt Account{}.',
            [3] = '{C:red}Gears{} and {C:blue}Experiences{} appear {C:green}2x{} more often.',
            [4] = '{C:blue}+1{} hand, {C:red}+1{} discard, {C:attention}+2{} Consumable Slots',
            [5] = 'Beat {C:attention}Ante 4{} to win.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
     apply = function(self, back)
            G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
            G.GAME.starting_params.discards = G.GAME.starting_params.discards + 1
            G.GAME.starting_params.dollars = G.GAME.starting_params.dollars +8
            G.GAME.win_ante = 4
            
            
        G.GAME.experience_rate = G.GAME.experience_rate +2
        
            
        G.GAME.gear_rate = G.GAME.gear_rate +2
        
            
        G.GAME.starting_params.consumable_slots = G.GAME.starting_params.consumable_slots + 2
            G.E_MANAGER:add_event(Event({
            func = function()
            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
  
            play_sound('timpani')
            SMODS.add_card({ set = 'Tarot', area = G.consumeables, key = 'c_rolatro_newuser'
             })
        end
        return true
        end
        }))
            if SMODS.pseudorandom_probability(back, 'group_0_edae2ba4', 1, self.config.odds, 'b_rolatro_deckfornoobs', false) then
                
                G.E_MANAGER:add_event(Event({
            func = function()
            for i = 1, 1 do
  
            play_sound('timpani')
            SMODS.add_card({ set = 'Tarot', area = G.consumeables, key = 'c_rolatro_altaccount'
             })
        end
        return true
        end
        }))
            end
    end
}