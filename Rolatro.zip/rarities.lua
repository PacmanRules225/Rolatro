SMODS.Rarity {
    key = "bloxxer",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.005,
    badge_colour = HEX('ff0000'),
    loc_txt = {
        name = "Bloxxer"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "epic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.025,
    badge_colour = HEX('f5a623'),
    loc_txt = {
        name = "Epic (Rolatro)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "c00l",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('5a0000'),
    loc_txt = {
        name = "c00l"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}