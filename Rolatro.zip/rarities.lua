SMODS.Rarity {
    key = "bloxxer",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('ff0000'),
    loc_txt = {
        name = "Bloxxer"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "epic",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.025,
    badge_colour = HEX('f5a623'),
    loc_txt = {
        name = "Epic (Rolatro)"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "cool",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('5a0000'),
    loc_txt = {
        name = "c00l"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "bluu",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0.001,
    badge_colour = HEX('799cd0'),
    loc_txt = {
        name = "Bluu"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}

SMODS.Rarity {
    key = "dandy",
    pools = {
        ["Joker"] = true
    },
    default_weight = 0,
    badge_colour = HEX('90d597'),
    loc_txt = {
        name = "Dandy"
    },
    get_weight = function(self, weight, object_type)
        return weight
    end,
}