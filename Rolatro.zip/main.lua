SMODS.Atlas({
    key = "modicon", 
    path = "ModIcon.png", 
    px = 34,
    py = 34,
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "balatro", 
    path = "balatro.png", 
    px = 333,
    py = 216,
    prefix_config = { key = false },
    atlas_table = "ASSET_ATLAS"
})


SMODS.Atlas({
    key = "CustomJokers", 
    path = "CustomJokers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomConsumables", 
    path = "CustomConsumables.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomBoosters", 
    path = "CustomBoosters.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomEnhancements", 
    path = "CustomEnhancements.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomSeals", 
    path = "CustomSeals.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
}):register()

SMODS.Atlas({
    key = "CustomVouchers", 
    path = "CustomVouchers.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

SMODS.Atlas({
    key = "CustomDecks", 
    path = "CustomDecks.png", 
    px = 71,
    py = 95, 
    atlas_table = "ASSET_ATLAS"
})

local NFS = require("nativefs")
to_big = to_big or function(a) return a end
lenient_bignum = lenient_bignum or function(a) return a end

local jokerIndexList = {37,28,10,57,25,13,42,58,53,33,36,34,24,4,11,39,45,66,32,9,38,63,3,7,64,22,51,1,50,30,49,20,6,14,56,29,62,59,43,12,19,17,46,35,31,60,61,52,40,55,21,16,44,8,54,2,26,15,48,47,41,27,23,5,65,18}

local function load_jokers_folder()
    local mod_path = SMODS.current_mod.path
    local jokers_path = mod_path .. "/jokers"
    local files = NFS.getDirectoryItemsInfo(jokers_path)
    for i = 1, #jokerIndexList do
        local file_name = files[jokerIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("jokers/" .. file_name))()
        end
    end
end


local consumableIndexList = {27,1,35,41,17,23,6,51,31,7,30,36,14,44,20,22,42,5,19,40,12,8,47,15,13,2,39,25,3,43,32,9,28,38,18,10,50,21,34,33,16,29,45,11,49,48,24,4,37,46,26}

local function load_consumables_folder()
    local mod_path = SMODS.current_mod.path
    local consumables_path = mod_path .. "/consumables"
    local files = NFS.getDirectoryItemsInfo(consumables_path)
    local set_file_number = #files + 1
    for i = 1, #files do
        if files[i].name == "sets.lua" then
            assert(SMODS.load_file("consumables/sets.lua"))()
            set_file_number = i
        end
    end    
    for i = 1, #consumableIndexList do
        local j = consumableIndexList[i]
        if j >= set_file_number then 
            j = j + 1
        end
        local file_name = files[j].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("consumables/" .. file_name))()
        end
    end
end


local enhancementIndexList = {1,2}

local function load_enhancements_folder()
    local mod_path = SMODS.current_mod.path
    local enhancements_path = mod_path .. "/enhancements"
    local files = NFS.getDirectoryItemsInfo(enhancements_path)
    for i = 1, #enhancementIndexList do
        local file_name = files[enhancementIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("enhancements/" .. file_name))()
        end
    end
end


local sealIndexList = {12,5,2,11,7,4,10,6,3,9,1,8}

local function load_seals_folder()
    local mod_path = SMODS.current_mod.path
    local seals_path = mod_path .. "/seals"
    local files = NFS.getDirectoryItemsInfo(seals_path)
    for i = 1, #sealIndexList do
        local file_name = files[sealIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("seals/" .. file_name))()
        end
    end
end


local editionIndexList = {2,3,1}

local function load_editions_folder()
    local mod_path = SMODS.current_mod.path
    local editions_path = mod_path .. "/editions"
    local files = NFS.getDirectoryItemsInfo(editions_path)
    for i = 1, #editionIndexList do
        local file_name = files[editionIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("editions/" .. file_name))()
        end
    end
end


local voucherIndexList = {7,8,1,6,3,2,4,5}

local function load_vouchers_folder()
    local mod_path = SMODS.current_mod.path
    local vouchers_path = mod_path .. "/vouchers"
    local files = NFS.getDirectoryItemsInfo(vouchers_path)
    for i = 1, #voucherIndexList do
        local file_name = files[voucherIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("vouchers/" .. file_name))()
        end
    end
end


local deckIndexList = {2,3,4,1}

local function load_decks_folder()
    local mod_path = SMODS.current_mod.path
    local decks_path = mod_path .. "/decks"
    local files = NFS.getDirectoryItemsInfo(decks_path)
    for i = 1, #deckIndexList do
        local file_name = files[deckIndexList[i]].name
        if file_name:sub(-4) == ".lua" then
            assert(SMODS.load_file("decks/" .. file_name))()
        end
    end
end

local function load_rarities_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("rarities.lua"))()
end

load_rarities_file()

local function load_boosters_file()
    local mod_path = SMODS.current_mod.path
    assert(SMODS.load_file("boosters.lua"))()
end

load_boosters_file()
assert(SMODS.load_file("sounds.lua"))()
load_jokers_folder()
load_consumables_folder()
load_enhancements_folder()
load_seals_folder()
load_editions_folder()
load_vouchers_folder()
load_decks_folder()
SMODS.ObjectType({
    key = "rolatro_food",
    cards = {
        ["j_gros_michel"] = true,
        ["j_egg"] = true,
        ["j_ice_cream"] = true,
        ["j_cavendish"] = true,
        ["j_turtle_bean"] = true,
        ["j_diet_cola"] = true,
        ["j_popcorn"] = true,
        ["j_ramen"] = true,
        ["j_selzer"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_rolatro_jokers",
    cards = {
        ["j_rolatro_ambush"] = true,
        ["j_rolatro_astro"] = true,
        ["j_rolatro_baconhair"] = true,
        ["j_rolatro_banhammer2"] = true,
        ["j_rolatro_blot"] = true,
        ["j_rolatro_bluudud"] = true,
        ["j_rolatro_bodyswappotion"] = true,
        ["j_rolatro_boxten"] = true,
        ["j_rolatro_builderman"] = true,
        ["j_rolatro_c00lkidd"] = true,
        ["j_rolatro_cartridejoker"] = true,
        ["j_rolatro_cashier"] = true,
        ["j_rolatro_cashierpizzaplace"] = true,
        ["j_rolatro_chance"] = true,
        ["j_rolatro_connie"] = true,
        ["j_rolatro_dandy"] = true,
        ["j_rolatro_disconnectionerror"] = true,
        ["j_rolatro_dummycatalogheaven"] = true,
        ["j_rolatro_dummygasa4"] = true,
        ["j_rolatro_dupe"] = true,
        ["j_rolatro_dusekkar"] = true,
        ["j_rolatro_elgoblinojeff"] = true,
        ["j_rolatro_finn"] = true,
        ["j_rolatro_garden"] = true,
        ["j_rolatro_giantnoob"] = true,
        ["j_rolatro_gigi"] = true,
        ["j_rolatro_glisten"] = true,
        ["j_rolatro_guest"] = true,
        ["j_rolatro_guest1337"] = true,
        ["j_rolatro_guidinglight"] = true,
        ["j_rolatro_headlesshorseman"] = true,
        ["j_rolatro_hotbar"] = true,
        ["j_rolatro_johndoe"] = true,
        ["j_rolatro_kyoko"] = true,
        ["j_rolatro_linked_sword"] = true,
        ["j_rolatro_noob"] = true,
        ["j_rolatro_noobinipizzanini"] = true,
        ["j_rolatro_officer"] = true,
        ["j_rolatro_onex"] = true,
        ["j_rolatro_pebble"] = true,
        ["j_rolatro_pizzadelivery"] = true,
        ["j_rolatro_playergasa4"] = true,
        ["j_rolatro_poppy"] = true,
        ["j_rolatro_prisoner"] = true,
        ["j_rolatro_rainingtacos"] = true,
        ["j_rolatro_razzledazzle"] = true,
        ["j_rolatro_rodger"] = true,
        ["j_rolatro_rush2"] = true,
        ["j_rolatro_screech"] = true,
        ["j_rolatro_seek"] = true,
        ["j_rolatro_servermaintenance"] = true,
        ["j_rolatro_shedletsky"] = true,
        ["j_rolatro_shrimpo"] = true,
        ["j_rolatro_skeleton"] = true,
        ["j_rolatro_slasher"] = true,
        ["j_rolatro_subspacetripmine"] = true,
        ["j_rolatro_supplier"] = true,
        ["j_rolatro_taph"] = true,
        ["j_rolatro_thedeer"] = true,
        ["j_rolatro_theowl"] = true,
        ["j_rolatro_twotime"] = true,
        ["j_rolatro_tycoon"] = true,
        ["j_rolatro_ugcjoker"] = true,
        ["j_rolatro_zombie"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_doors",
    cards = {
        ["j_rolatro_ambush"] = true,
        ["j_rolatro_dupe"] = true,
        ["j_rolatro_elgoblinojeff"] = true,
        ["j_rolatro_guidinglight"] = true,
        ["j_rolatro_rush2"] = true,
        ["j_rolatro_screech"] = true,
        ["j_rolatro_seek"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_elevator_allowed",
    cards = {
        ["j_rolatro_ambush"] = true,
        ["j_rolatro_baconhair"] = true,
        ["j_rolatro_banhammer2"] = true,
        ["j_rolatro_bluudud"] = true,
        ["j_rolatro_bodyswappotion"] = true,
        ["j_rolatro_builderman"] = true,
        ["j_rolatro_c00lkidd"] = true,
        ["j_rolatro_cartridejoker"] = true,
        ["j_rolatro_chance"] = true,
        ["j_rolatro_elgoblinojeff"] = true,
        ["j_rolatro_garden"] = true,
        ["j_rolatro_guest"] = true,
        ["j_rolatro_guest1337"] = true,
        ["j_rolatro_hugejokerpet"] = true,
        ["j_rolatro_johndoe"] = true,
        ["j_rolatro_linked_sword"] = true,
        ["j_rolatro_noob"] = true,
        ["j_rolatro_noobinipizzanini"] = true,
        ["j_rolatro_pizzadelivery"] = true,
        ["j_rolatro_playergasa4"] = true,
        ["j_rolatro_prisoner"] = true,
        ["j_rolatro_rush2"] = true,
        ["j_rolatro_screech"] = true,
        ["j_rolatro_seek"] = true,
        ["j_rolatro_shedletsky"] = true,
        ["j_rolatro_subspacetripmine"] = true,
        ["j_rolatro_twotime"] = true,
        ["j_rolatro_tycoon"] = true,
        ["j_rolatro_ugcjoker"] = true,
        ["j_rolatro_zombie"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_dandy",
    cards = {
        ["j_rolatro_astro"] = true,
        ["j_rolatro_blot"] = true,
        ["j_rolatro_connie"] = true,
        ["j_rolatro_dandy"] = true,
        ["j_rolatro_finn"] = true,
        ["j_rolatro_gigi"] = true,
        ["j_rolatro_glisten"] = true,
        ["j_rolatro_pebble"] = true,
        ["j_rolatro_poppy"] = true,
        ["j_rolatro_razzledazzle"] = true,
        ["j_rolatro_rodger"] = true,
        ["j_rolatro_shrimpo"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_roblox",
    cards = {
        ["j_rolatro_baconhair"] = true,
        ["j_rolatro_banhammer2"] = true,
        ["j_rolatro_bodyswappotion"] = true,
        ["j_rolatro_builderman"] = true,
        ["j_rolatro_c00lkidd"] = true,
        ["j_rolatro_cartridejoker"] = true,
        ["j_rolatro_garden"] = true,
        ["j_rolatro_giantnoob"] = true,
        ["j_rolatro_guest"] = true,
        ["j_rolatro_hotbar"] = true,
        ["j_rolatro_johndoe"] = true,
        ["j_rolatro_linked_sword"] = true,
        ["j_rolatro_noob"] = true,
        ["j_rolatro_noobinipizzanini"] = true,
        ["j_rolatro_officer"] = true,
        ["j_rolatro_pizzadelivery"] = true,
        ["j_rolatro_prisoner"] = true,
        ["j_rolatro_shedletsky"] = true,
        ["j_rolatro_slasher"] = true,
        ["j_rolatro_subspacetripmine"] = true,
        ["j_rolatro_tycoon"] = true,
        ["j_rolatro_zombie"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_modern",
    cards = {
        ["j_rolatro_baconhair"] = true,
        ["j_rolatro_banhammer2"] = true,
        ["j_rolatro_cashier"] = true,
        ["j_rolatro_disconnectionerror"] = true,
        ["j_rolatro_dummygasa4"] = true,
        ["j_rolatro_garden"] = true,
        ["j_rolatro_guest1337"] = true,
        ["j_rolatro_johndoe"] = true,
        ["j_rolatro_kyoko"] = true,
        ["j_rolatro_officer"] = true,
        ["j_rolatro_playergasa4"] = true,
        ["j_rolatro_prisoner"] = true,
        ["j_rolatro_servermaintenance"] = true,
        ["j_rolatro_taph"] = true,
        ["j_rolatro_tycoon"] = true,
        ["j_rolatro_ugcjoker"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_forsaken",
    cards = {
        ["j_rolatro_bluudud"] = true,
        ["j_rolatro_builderman"] = true,
        ["j_rolatro_c00lkidd"] = true,
        ["j_rolatro_chance"] = true,
        ["j_rolatro_guest1337"] = true,
        ["j_rolatro_johndoe"] = true,
        ["j_rolatro_noob"] = true,
        ["j_rolatro_shedletsky"] = true,
        ["j_rolatro_taph"] = true,
        ["j_rolatro_twotime"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_legendary",
    cards = {
        ["j_rolatro_builderman"] = true,
        ["j_rolatro_guidinglight"] = true,
        ["j_rolatro_headlesshorseman"] = true,
        ["j_rolatro_hotbar"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_myth",
    cards = {
        ["j_rolatro_c00lkidd"] = true,
        ["j_rolatro_johndoe"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_retro",
    cards = {
        ["j_rolatro_cartridejoker"] = true,
        ["j_rolatro_cashierpizzaplace"] = true,
        ["j_rolatro_disconnectionerror"] = true,
        ["j_rolatro_giantnoob"] = true,
        ["j_rolatro_guest"] = true,
        ["j_rolatro_headlesshorseman"] = true,
        ["j_rolatro_linked_sword"] = true,
        ["j_rolatro_noob"] = true,
        ["j_rolatro_noobinipizzanini"] = true,
        ["j_rolatro_pizzadelivery"] = true,
        ["j_rolatro_rainingtacos"] = true,
        ["j_rolatro_shedletsky"] = true,
        ["j_rolatro_skeleton"] = true,
        ["j_rolatro_slasher"] = true,
        ["j_rolatro_subspacetripmine"] = true,
        ["j_rolatro_supplier"] = true,
        ["j_rolatro_tycoon"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_getasnack",
    cards = {
        ["j_rolatro_cashier"] = true,
        ["j_rolatro_dummygasa4"] = true,
        ["j_rolatro_playergasa4"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_mansion",
    cards = {
        ["j_rolatro_headlesshorseman"] = true,
        ["j_rolatro_skeleton"] = true,
        ["j_rolatro_zombie"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_blocktales",
    cards = {
        ["j_rolatro_kyoko"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_brickbattle",
    cards = {
        ["j_rolatro_linked_sword"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_jailbreak",
    cards = {
        ["j_rolatro_officer"] = true,
        ["j_rolatro_prisoner"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_forestnights",
    cards = {
        ["j_rolatro_thedeer"] = true,
        ["j_rolatro_theowl"] = true
    },
})

SMODS.ObjectType({
    key = "rolatro_innovationinc",
    cards = {
        ["j_rolatro_zombie"] = true
    },
})