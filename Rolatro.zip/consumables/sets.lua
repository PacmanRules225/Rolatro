SMODS.ConsumableType {
    key = 'gear',
    primary_colour = HEX('ff0000'),
    secondary_colour = HEX('ff0000'),
    collection_rows = { 4, 5 },
    shop_rate = 1,
    cards = {
        ['c_rolatro_cheezburger'] = true,
        ['c_rolatro_fusebomb'] = true,
        ['c_rolatro_gravitycoil'] = true,
        ['c_rolatro_pizza'] = true,
        ['c_rolatro_rocketlauncher'] = true,
        ['c_rolatro_speedcoil'] = true
    },
    loc_txt = {
        name = "Gear",
        collection = "Gears",
    }
}

SMODS.ConsumableType {
    key = 'experience',
    primary_colour = HEX('335fff'),
    secondary_colour = HEX('335fff'),
    collection_rows = { 5, 5 },
    shop_rate = 1,
    cards = {
        ['c_rolatro_contentdeleted'] = true,
        ['c_rolatro_glasshouses'] = true,
        ['c_rolatro_growagarden'] = true,
        ['c_rolatro_jailbreak'] = true,
        ['c_rolatro_makeacake'] = true,
        ['c_rolatro_petsimulator99'] = true,
        ['c_rolatro_starterplace'] = true,
        ['c_rolatro_stealabrainrot'] = true,
        ['c_rolatro_pizzaplace'] = true
    },
    loc_txt = {
        name = "Experience",
        collection = "Experiences",
    }
}