SMODS.ConsumableType {
    key = 'gear',
    primary_colour = HEX('ff0000'),
    secondary_colour = HEX('ff0000'),
    collection_rows = { 4, 5 },
    shop_rate = 10,
    cards = {
        ['c_rolatro_robloxgiftcard'] = true,
        ['c_rolatro_cheezburger'] = true,
        ['c_rolatro_pizza'] = true,
        ['c_rolatro_rocket_launcher'] = true,
        ['c_rolatro_fuse_bomb2'] = true,
        ['c_rolatro_gravitycoil'] = true,
        ['c_rolatro_speedcoil'] = true,
        ['c_rolatro_crucifix'] = true,
        ['c_rolatro_tipjar'] = true,
        ['c_rolatro_bloxiade'] = true,
        ['c_rolatro_spacesandwich'] = true,
        ['c_rolatro_bloxycola'] = true,
        ['c_rolatro_taco'] = true,
        ['c_rolatro_slateskinpotion'] = true,
        ['c_rolatro_goldchalice'] = true,
        ['c_rolatro_decoydeploy'] = true,
        ['c_rolatro_witchesbrew'] = true,
        ['c_rolatro_robar'] = true,
        ['c_rolatro_pumpkinbucket'] = true,
        ['c_rolatro_ghostbag'] = true,
        ['c_rolatro_noxiouschocolate'] = true,
        ['c_rolatro_theemperor'] = true
    },
    loc_txt = {
        name = "Gear",
        collection = "Gears",
    }
}

SMODS.ConsumableType {
    key = 'experience',
    primary_colour = HEX('335fff'),
    secondary_colour = HEX('335fff'),
    collection_rows = { 5, 5 },
    shop_rate = 5,
    cards = {
        ['c_rolatro_starterplace'] = true,
        ['c_rolatro_glass_houses'] = true,
        ['c_rolatro_makeacake'] = true,
        ['c_rolatro_work_at_a_pizza_place'] = true,
        ['c_rolatro_content_deleted'] = true,
        ['c_rolatro_petsimulator99'] = true,
        ['c_rolatro_grow_a_garden'] = true,
        ['c_rolatro_jailbreak'] = true,
        ['c_rolatro_stealabrainrot'] = true,
        ['c_rolatro_doors'] = true,
        ['c_rolatro_getasnackat4am'] = true,
        ['c_rolatro_forsaken'] = true,
        ['c_rolatro_mymovie'] = true,
        ['c_rolatro_dandysworld'] = true,
        ['c_rolatro_nightsintheforest'] = true,
        ['c_rolatro_hauntedmansion'] = true,
        ['c_rolatro_nds'] = true
    },
    loc_txt = {
        name = "Experience",
        collection = "Experiences",
    }
}

SMODS.ConsumableType {
    key = 'gamepass',
    primary_colour = HEX('009273'),
    secondary_colour = HEX('009273'),
    collection_rows = { 5, 5 },
    shop_rate = 2.5,
    cards = {
        ['c_rolatro_donation'] = true,
        ['c_rolatro_vip'] = true,
        ['c_rolatro_tripletag'] = true,
        ['c_rolatro_morejokerslots'] = true,
        ['c_rolatro_bossbeatdown'] = true,
        ['c_rolatro_skipstage'] = true,
        ['c_rolatro_thewheeloffortune'] = true
    },
    loc_txt = {
        name = "Gamepass",
        collection = "Gamepasses",
    }
}