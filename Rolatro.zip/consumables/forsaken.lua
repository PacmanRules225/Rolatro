SMODS.Consumable {
    key = 'forsaken',
    set = 'experience',
    pos = { x = 4, y = 2 },
    loc_txt = {
        name = 'Forsaken',
        text = {
        [1] = '{C:inactive}\"Welcome to your eternal prison.\"{}',
        [2] = 'Enables any {C:purple}Forsaken-exclusive{} abilities',
        [3] = '{C:attention}certain Jokers{} have.',
        [4] = 'Specific {C:attention}Forsaken Jokers{} can now appear',
        [5] = 'outside of {C:attention}Purgatory Packs{}'
    }
    },
    cost = 20,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "The Spectre rises...", colour = G.C.BLUE})
                    G.GAME.pool_flags.rolatro_Forsaken = true
                    return true
                end
            }))
            delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}