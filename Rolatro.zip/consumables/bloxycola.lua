SMODS.Consumable {
    key = 'bloxycola',
    set = 'gear',
    pos = { x = 2, y = 0 },
    config = { extra = {
        blind_size_value = 0.9
    } },
    loc_txt = {
        name = 'Bloxy Cola',
        text = {
        [1] = 'Reduces {C:attention}Blind Requirement{} by {C:attention}0.9x{}.'
    }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
        if G.GAME.blind.in_blind then
            play_sound("rolatro_colasip")
            G.E_MANAGER:add_event(Event({
      func = function()
                card_eval_status_text(card, 'extra', nil, nil, nil, {message = "X"..tostring(0.9).." Blind Size", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips * 0.9
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                    }))
        delay(0.5)
        end
    end,
    can_use = function(self, card)
        return (G.GAME.blind.in_blind)
    end
}