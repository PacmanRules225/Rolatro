SMODS.Consumable {
    key = 'tripletag',
    set = 'gamepass',
    pos = { x = 6, y = 4 },
    config = { extra = {
        repetitions = 2
    } },
    loc_txt = {
        name = 'Triple Tag',
        text = {
        [1] = 'Adds {C:attention}2 Double Tags{}'
    }
    },
    cost = 15,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
            for i = 1, card.ability.extra.repetitions do
              
                G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_double")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
          end
    end,
    can_use = function(self, card)
        return true
    end
}