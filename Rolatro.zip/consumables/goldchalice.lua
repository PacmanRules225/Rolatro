SMODS.Consumable {
    key = 'goldchalice',
    set = 'gear',
    pos = { x = 4, y = 3 },
    config = { extra = {
        add_cards_count = 5
    } },
    loc_txt = {
        name = 'Seranoks Golden Chalice of Fame',
        text = {
        [1] = '{C:inactive}\"Hold this chalice while it oozes fame all{}',
        [2] = '{C:inactive}around you spawning pawns as you go\"{}',
        [3] = 'When used, adds {C:attention}{}5 {C:enhanced}Gold{} cards to {C:attention}hand{}'
    }
    },
    cost = 8,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
        if G.GAME.blind.in_blind then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.7,
                func = function()
                    local cards = {}
                    for i = 1, 5 do
                        local _rank = pseudorandom_element(SMODS.Ranks, 'add_random_rank').card_key
                        local _suit = nil
                        local enhancement = G.P_CENTERS['m_gold']
                        local new_card_params = { set = "Base" }
                        if _rank then new_card_params.rank = _rank end
                        if _suit then new_card_params.suit = _suit end
                        if enhancement then new_card_params.enhancement = enhancement.key end
                        cards[i] = SMODS.add_card(new_card_params)
                    end
                    SMODS.calculate_context({ playing_card_added = true, cards = cards })
                    return true
                end
            }))
            delay(0.3)
        end
    end,
    can_use = function(self, card)
        return (G.GAME.blind.in_blind)
    end
}