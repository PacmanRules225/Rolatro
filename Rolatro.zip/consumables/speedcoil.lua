SMODS.Consumable {
    key = 'speedcoil',
    set = 'gear',
    pos = { x = 3, y = 1 },
    config = { extra = {
        booster_slots_value = 1
    } },
    loc_txt = {
        name = 'Speed Coil',
        text = {
        [1] = '{C:attention}+1{} Booster Slot to the shop'
    }
    },
    cost = 6,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            play_sound("rolatro_speedcoil")
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Booster Slots", colour = G.C.BLUE})
                    SMODS.change_booster_limit(1)
                    return true
                end
            }))
            delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}