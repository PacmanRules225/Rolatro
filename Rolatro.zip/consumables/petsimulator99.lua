SMODS.Consumable {
    key = 'petsimulator99',
    set = 'experience',
    pos = { x = 8, y = 1 },
    config = { extra = {
        odds = 750,
        odds = 500,
        odds = 250
    } },
    loc_txt = {
        name = 'Pet Simulator 99',
        text = {
        [1] = '{C:inactive}\"Keep hatching for that HUGE!\"{}',
        [2] = '',
        [3] = '{C:green}1 in ???{} chance to get the {C:attention}HUGE Joker Pet{}',
        [4] = '{C:inactive}(You probably shouldn\'t make room){}'
    }
    },
    cost = 1,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
        if (not ((G.GAME.pool_flags.rolatro_Lucky or false)) and not ((G.GAME.pool_flags.rolatro_UltraLucky or false))) then
            if SMODS.pseudorandom_probability(card, 'group_0_a6027846', 1, card.ability.extra.odds, 'c_rolatro_petsimulator99', true) then
                
                G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_hugejokerpet' })
                      if new_joker then
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
            end
        end
        if ((G.GAME.pool_flags.rolatro_Lucky or false) and not ((G.GAME.pool_flags.rolatro_UltraLucky or false))) then
            if SMODS.pseudorandom_probability(card, 'group_0_f526e5a7', 1, card.ability.extra.odds, 'c_rolatro_petsimulator99', true) then
                
                G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_hugejokerpet' })
                      if new_joker then
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
            end
        end
        if (not ((G.GAME.pool_flags.rolatro_Lucky or false)) and (G.GAME.pool_flags.rolatro_UltraLucky or false)) then
            if SMODS.pseudorandom_probability(card, 'group_0_32b00bb8', 1, card.ability.extra.odds, 'c_rolatro_petsimulator99', true) then
                
                G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_hugejokerpet' })
                      if new_joker then
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
            end
        end
    end,
    can_use = function(self, card)
        return ((not ((G.GAME.pool_flags.rolatro_Lucky or false)) and not ((G.GAME.pool_flags.rolatro_UltraLucky or false)))) or (((G.GAME.pool_flags.rolatro_Lucky or false) and not ((G.GAME.pool_flags.rolatro_UltraLucky or false)))) or ((not ((G.GAME.pool_flags.rolatro_Lucky or false)) and (G.GAME.pool_flags.rolatro_UltraLucky or false)))
    end
}