SMODS.Consumable {
    key = 'tipjar',
    set = 'gear',
    pos = { x = 2, y = 2 },
    config = { extra = {
        double_limit = 40
    } },
    loc_txt = {
        name = 'Tip Jar',
        text = {
        [1] = '{C:green}Originated From: DOORS{}',
        [2] = '{C:white}-{}',
        [3] = 'Doubles money',
        [4] = '{C:inactive}(Max of {}{C:money}$40{}{C:inactive}){}'
    }
    },
    cost = 12,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    local double_amount = math.min(G.GAME.dollars, 40)
                    ease_dollars(double_amount, true)
                    return true
                end
            }))
            delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}