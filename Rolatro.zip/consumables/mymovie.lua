SMODS.Consumable {
    key = 'mymovie',
    set = 'experience',
    pos = { x = 5, y = 2 },
    loc_txt = {
        name = 'My Movie',
        text = {
        [1] = '{C:inactive}\"You\'re the man now, dawg!\"{}',
        [2] = '',
        [3] = '{C:attention}Immediately{} redeems the {C:attention}Director\'s Cut{}',
        [4] = 'voucher'
    }
    },
    cost = 8,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
        if not (G.GAME.used_vouchers["v_directors_cut"]) then
            local voucher_key = "v_directors_cut"
    local voucher_card = SMODS.create_card{area = G.play, key = voucher_key}
    voucher_card:start_materialize()
    voucher_card.cost = 0
    G.play:emplace(voucher_card)
    delay(0.8)
    voucher_card:redeem()

    G.E_MANAGER:add_event(Event({
        trigger = 'after',
        delay = 0.5,
        func = function()
            voucher_card:start_dissolve()                
            return true
        end
    }))
        end
    end,
    can_use = function(self, card)
        return (not (G.GAME.used_vouchers["v_directors_cut"]))
    end
}