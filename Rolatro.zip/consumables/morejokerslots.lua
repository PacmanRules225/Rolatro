SMODS.Consumable {
    key = 'morejokerslots',
    set = 'gamepass',
    pos = { x = 7, y = 4 },
    config = { extra = {
        joker_slots_value = 5
    } },
    loc_txt = {
        name = 'More Joker Slots',
        text = {
        [1] = '{C:attention}+5 Joker{} slots',
        [2] = '{C:white}-{}',
        [3] = '{C:red}After use, this gamepass will{}',
        [4] = '{C:red}no longer appear in the run.{}'
    }
    },
    cost = 25,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(5).." Joker Slot", colour = G.C.DARK_EDITION})
                    G.jokers.config.card_limit = G.jokers.config.card_limit + 5
                    return true
                end
            }))
            delay(0.6)
            G.P_CENTERS["c_rolatro_morejokerslots"].in_pool = function() return false end
    end,
    can_use = function(self, card)
        return true
    end
}