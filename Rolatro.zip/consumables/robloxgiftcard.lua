SMODS.Consumable {
    key = 'robloxgiftcard',
    set = 'gear',
    pos = { x = 2, y = 0 },
    config = { extra = {
        dollars_value = 10,
        odds = 2
    } },
    loc_txt = {
        name = 'Roblox Gift Card',
        text = {
        [1] = '{C:money}+$10-100{}'
    }
    },
    cost = 15,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            if SMODS.pseudorandom_probability(card, 'group_0_9d5d4998', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_1_618e052a', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_2_c34cc2b4', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_3_04053f0f', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_4_ba0e457b', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_5_67c54474', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_6_0aebf3fc', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_7_2a9b8248', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_8_a651ee5b', 1, card.ability.extra.odds, 'c_rolatro_robloxgiftcard', true) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(10).." $", colour = G.C.MONEY})
                    ease_dollars(10, true)
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}