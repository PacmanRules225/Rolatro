SMODS.Voucher {
    key = 'rng',
    pos = { x = 5, y = 0 },
    config = { extra = {
        rellors_value = 1
    } },
    loc_txt = {
        name = 'Jimbos RNG',
        text = {
        [1] = 'The first reroll is {C:green}free{}.'
    }
    },
    cost = 6,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            SMODS.change_free_rerolls(1)
    end
}