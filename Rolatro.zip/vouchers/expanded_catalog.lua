SMODS.Voucher {
    key = 'expanded_catalog',
    pos = { x = 3, y = 0 },
    config = { extra = {
        item_rate = 20
    } },
    loc_txt = {
        name = 'Expanded Catalog',
        text = {
        [1] = '{C:red}Gear{} Cards appear in the shop',
        [2] = '{C:attention}2x{} more often.'
    }
    },
    cost = 7,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_gear_rate = 20
                return true
            end
        }))
    end
}