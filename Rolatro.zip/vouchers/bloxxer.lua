SMODS.Voucher {
    key = 'bloxxer',
    pos = { x = 0, y = 0 },
    config = { extra = {
        rarity_rate = 0.05
    } },
    loc_txt = {
        name = 'Bloxxer',
        text = {
        [1] = '{C:red}Bloxxer{} rarity {C:attention}Jokers{} now appear',
        [2] = 'in the shop.'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_bloxxer_mod = 0.05
                return true
            end
        }))
    end
}