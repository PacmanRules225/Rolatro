SMODS.Voucher {
    key = 'catalog_heaven',
    pos = { x = 2, y = 0 },
    config = { extra = {
        item_rate = 20
    } },
    loc_txt = {
        name = 'Catalog Heaven',
        text = {
        [1] = '{C:red}Gear{} Cards appear in the shop',
        [2] = '{C:attention}4x{} more often.'
    }
    },
    cost = 10,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_rolatro_expanded_catalog'},
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_gear_rate = 20
                return true
            end
        }))
    end
}