SMODS.Voucher {
    key = 'negative_bloxxer',
    pos = { x = 3, y = 0 },
    config = { extra = {
        rarity_rate = 0.1
    } },
    loc_txt = {
        name = 'Negative Bloxxer',
        text = {
            [1] = '{C:red}Bloxxer{} rarity {C:attention}Jokers{} appear',
            [2] = 'in the shop more often.'
        },
        unlock = {
            [1] = ''
        }
    },
    cost = 15,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_rolatro_bloxxer'},
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_bloxxer_mod = 0.1
                return true
            end
        }))
    end
}