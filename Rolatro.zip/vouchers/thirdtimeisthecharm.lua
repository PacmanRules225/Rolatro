SMODS.Voucher {
    key = 'thirdtimeisthecharm',
    pos = { x = 1, y = 0 },
    config = { extra = {
        rellors_value = 2
    } },
    loc_txt = {
        name = 'Third Time is the Charm',
        text = {
            [1] = 'The first {C:attention}2{} rerolls are {C:green}free{}.'
        },
        unlock = {
            [1] = ''
        }
    },
    cost = 12,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_rolatro_rng'},
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            SMODS.change_free_rerolls(2)
    end
}