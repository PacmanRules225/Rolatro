SMODS.Voucher {
    key = 'home_page',
    pos = { x = 4, y = 0 },
    config = { extra = {
        item_rate = 20
    } },
    loc_txt = {
        name = 'Home Page',
        text = {
        [1] = '{C:blue}Experience{} Cards appear in the shop',
        [2] = '{C:attention}4x{} more often.'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_rolatro_front_page'},
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_experience_rate = 20
                return true
            end
        }))
    end
}