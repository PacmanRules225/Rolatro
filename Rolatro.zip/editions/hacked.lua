SMODS.Shader({ key = 'anaglyphic', path = 'anaglyphic.fs' })

SMODS.Edition {
    key = 'hacked',
    shader = 'anaglyphic',
    config = {
        extra = {
            exp_mult = 1.1
        }
    },
    in_shop = false,
    apply_to_float = true,
    badge_colour = HEX('005700'),
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Hacked',
        label = 'Hacked',
        text = {
        [1] = '{X:mult,C:white}^1.1{} Mult'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
  
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return { e_mult = card.edition.extra.exp_mult }
        end
    end
}