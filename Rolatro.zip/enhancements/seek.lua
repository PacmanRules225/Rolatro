SMODS.Enhancement {
    key = 'seek',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 3,
            chips = 75,
            chips = 25
        }
    },
    loc_txt = {
        name = 'Seek',
        text = {
        [1] = '{C:red}This isn\'t a card.{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and not ((G.GAME.pool_flags.rolatro_SeekVoucher or false)) then
            if pseudorandom('group_0_625dbbce') < 1 / card.ability.extra.odds then
                SMODS.calculate_effect({chips = card.ability.extra.chips}, card)
            end
        end
        if context.main_scoring and context.cardarea == G.play and (G.GAME.pool_flags.rolatro_SeekVoucher or false) then
            return { chips = card.ability.extra.chips }
        end
    end
}