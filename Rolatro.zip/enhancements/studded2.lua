SMODS.Enhancement {
    key = 'studded2',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            x_mult = 1.25
        }
    },
    loc_txt = {
        name = 'Studded',
        text = {
        [1] = '{X:mult,C:white}X1.25{} Mult while this card is held in hand'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 6.5,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { x_mult = card.ability.extra.x_mult }
        end
    end
}