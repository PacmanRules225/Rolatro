SMODS.Seal {
    key = 'obc',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            x_chips = 1.4
        }
    },
    badge_colour = HEX('c2a500'),
   loc_txt = {
        name = 'Outrageous Builders Club',
        label = 'Outrageous Builders Club',
        text = {
        [1] = '{X:chips,C:white}X1.4{} Chips'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_chips = card.ability.seal.extra.x_chips }
        end
    end
}