SMODS.Seal {
    key = 'barnaby',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            highestrankinhand = 0
        }
    },
    badge_colour = HEX('775cbb'),
   loc_txt = {
        name = 'Barnaby Wilikers',
        label = 'Barnaby Wilikers',
        text = {
        [1] = '{C:green}Originated From: Dandy\'s World{}',
        [2] = '{C:white}-{}',
        [3] = 'While held in hand, this card will',
        [4] = 'add {C:blue}Chips{} based off of the {C:attention}highest rank{}',
        [5] = 'in {C:attention}your scoring hand{}.'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "splash_buildup", per = 1.2, vol = 0.4 },
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { chips = (function() local max = 0; for _, card in ipairs(G.hand and G.hand.cards or {}) do if card.base.id > max then max = card.base.id end end; return max end)() }
        end
    end
}