SMODS.Seal {
    key = 'bc',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            x_chips = 1.1
        }
    },
    badge_colour = HEX('0084ff'),
   loc_txt = {
        name = 'Builders Club',
        label = 'Builders Club',
        text = {
        [1] = '{X:chips,C:white}X1.1{} Chips'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_chips = card.ability.seal.extra.x_chips }
        end
    end
}