SMODS.Seal {
    key = 'popseal',
    pos = { x = 9, y = 0 },
    badge_colour = HEX('da2871'),
   loc_txt = {
        name = 'Pop Seal',
        label = 'Pop Seal',
        text = {
        [1] = '{C:green}Originated From: Dandy\'s World{}',
        [2] = '{C:white}-{}',
        [3] = '{C:blue}+45{} Chips'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    sound = { sound = "coin1", per = 1.2, vol = 0.4 },
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
        end
    end
}