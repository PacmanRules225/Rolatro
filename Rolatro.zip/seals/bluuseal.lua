SMODS.Seal {
    key = 'bluuseal',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            chips = 100
        }
    },
    badge_colour = HEX('799CD0'),
   loc_txt = {
        name = 'Bluu Seal',
        label = 'Bluu Seal',
        text = {
        [1] = '{C:chips}+100{} Chips'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { chips = card.ability.seal.extra.chips }
        end
    end
}