SMODS.Seal {
    key = 'chatfilter',
    pos = { x = 2, y = 0 },
    badge_colour = HEX('828282'),
   loc_txt = {
        name = 'Chat Filter',
        label = 'Chat Filter',
        text = {
        [1] = 'Immediately {C:red}filtered/destroyed{}',
        [2] = 'upon {C:attention}being scored{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            G.E_MANAGER:add_event(Event({
                func = function()
                    card:start_dissolve()
                    return true
                end
            }))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Destroyed!", colour = G.C.RED})
            return
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            card.should_destroy = true
        end
    end
}