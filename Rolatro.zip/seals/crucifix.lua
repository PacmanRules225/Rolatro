SMODS.Seal {
    key = 'crucifix',
    pos = { x = 7, y = 0 },
    config = {
        extra = {
            x_chips = 1.2
        }
    },
    badge_colour = HEX('4ECDC4'),
   loc_txt = {
        name = 'Crucifix Seal',
        label = 'Crucifix Seal',
        text = {
        [1] = '{C:green}Originated From: DOORS (somewhat){}',
        [2] = '{C:white}-{}',
        [3] = '{X:chips,C:white}X1.2{} Chips while held in hand'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            return { x_chips = card.ability.seal.extra.x_chips }
        end
    end
}