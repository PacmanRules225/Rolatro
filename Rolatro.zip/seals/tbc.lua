SMODS.Seal {
    key = 'tbc',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            x_chips = 1.25
        }
    },
    badge_colour = HEX('ff6600'),
   loc_txt = {
        name = 'Turbo Builders Club',
        label = 'Turbo Builders Club',
        text = {
        [1] = '{X:chips,C:white}X1.25{} Chips'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_chips = card.ability.seal.extra.x_chips }
        end
    end
}