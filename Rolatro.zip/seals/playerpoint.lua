SMODS.Seal {
    key = 'playerpoint',
    pos = { x = 1, y = 1 },
    config = {
        extra = {
            x_mult = 2
        }
    },
    badge_colour = HEX('e14737'),
   loc_txt = {
        name = 'Player Point',
        label = 'Player Point',
        text = {
        [1] = '{X:mult,C:white}X2{} Mult'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = card.ability.seal.extra.x_mult }
        end
    end
}