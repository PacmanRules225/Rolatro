SMODS.Seal {
    key = 'seek',
    pos = { x = 6, y = 0 },
    config = {
        extra = {
            odds = 2
        }
    },
    badge_colour = HEX('000000'),
   loc_txt = {
        name = 'Seek',
        label = 'Seek',
        text = {
        [1] = '{C:red}This isn\'t a seal.{}'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.main_scoring then
            if SMODS.pseudorandom_probability(card, 'group_0_d7985e20', 1, card.ability.seal.extra.odds, 'm_rolatro_seek') then
                SMODS.calculate_effect({func = function()
                card:set_ability(G.P_CENTERS.m_rolatro_seek)
                card:set_seal(nil)
                    end}, card)
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
            end
        end
    end
}