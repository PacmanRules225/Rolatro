SMODS.Voucher {
    key = 'seekvoucher',
    pos = { x = 0, y = 0 },
    loc_txt = {
        name = '???',
        text = {
        [1] = '{C:red}This isn\'t a voucher.{}',
        [2] = '{C:white}-{}',
        [3] = '{C:attention}Seek enhanced{} cards are now',
        [4] = '{C:attention}guaranteed{} to successfully trigger,',
        [5] = 'but they now give {C:blue}+25{} {C:attention}chips{}',
        [6] = 'instead of {C:blue}+75{}.'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "SeekVoucher", colour = G.C.BLUE})
                    G.GAME.pool_flags.rolatro_SeekVoucher = true
    end
}