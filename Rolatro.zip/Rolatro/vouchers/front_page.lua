SMODS.Voucher {
    key = 'front_page',
    pos = { x = 4, y = 0 },
    config = { extra = {
        item_rate = 10
    } },
    loc_txt = {
        name = 'Front Page',
        text = {
        [1] = '{C:blue}Experience{} Cards appear in the shop',
        [2] = '{C:attention}2x{} more often.'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_experience_rate = 10
                return true
            end
        }))
    end
}