SMODS.Voucher {
    key = 'negative_bloxxer',
    pos = { x = 7, y = 0 },
    config = { extra = {
        rarity_rate = 0.05
    } },
    loc_txt = {
        name = 'Negative Bloxxer',
        text = {
        [1] = '{C:red}Bloxxer{} rarity Jokers appear',
        [2] = 'in the shop as often as {C:rare}Rare{}',
        [3] = 'Jokers.'
    }
    },
    cost = 15,
    unlocked = true,
    discovered = true,
    no_collection = false,
    can_repeat_soul = false,
    requires = {'v_rolatro_bloxxer'},
    atlas = 'CustomVouchers',
     redeem = function(self, card)
            G.E_MANAGER:add_event(Event({
            func = function()
        G.GAME.rolatro_bloxxer_mod = 0.05
                return true
            end
        }))
    end
}