SMODS.Seal {
    key = 'coolseal',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            x_chips = 0.9,
            mult = -0.1
        }
    },
    badge_colour = HEX('ff0000'),
   loc_txt = {
        name = 'c00l Seal',
        label = 'c00l Seal',
        text = {
        [1] = '{X:chips,C:white}X0.9{} Chips',
        [2] = '{C:mult}-0.1{} Mult'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_chips = card.ability.seal.extra.x_chips, mult = card.ability.seal.extra.mult }
        end
    end
}