SMODS.Seal {
    key = 'timothy',
    pos = { x = 7, y = 0 },
    badge_colour = HEX('292929'),
   loc_txt = {
        name = 'Timothy',
        label = 'Timothy',
        text = {
        [1] = '{C:green}Originated From: DOORS{}',
        [2] = '{C:white}-{}',
        [3] = 'It only exists as a {C:attention}nuisance{}.',
        [4] = '{C:attention}Score this card{} to get rid of Timothy.'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            card:set_seal(nil)
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
        end
    end
}