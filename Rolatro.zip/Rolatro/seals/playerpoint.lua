
SMODS.Seal {
    key = 'playerpoint',
    pos = { x = 0, y = 1 },
    config = {
        extra = {
            xmult0 = 2
        }
    },
    badge_colour = HEX('e14737'),
    loc_txt = {
        name = 'Player Point',
        label = 'Player Point',
        text = {
            [1] = '{X:mult,C:white}X2{} Mult'
        }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return {
                Xmult = 2
            }
        end
    end
}