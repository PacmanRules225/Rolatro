
SMODS.Enhancement {
    key = 'seek',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            odds = 3,
            chips0 = 75,
            chips = 25
        }
    },
    loc_txt = {
        name = 'Seek',
        text = {
            [1] = '{C:red}This isn\'t a card.{}'
        }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = true,
    no_rank = true,
    no_suit = true,
    always_scores = true,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 0,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play and not ((G.GAME.pool_flags.rolatro_SeekVoucher or false)) then
            if SMODS.pseudorandom_probability(card, 'group_0_625dbbce', 1, card.ability.extra.odds, 'j_rolatro_seek', true) then
                SMODS.calculate_effect({chips = 75}, card)
            end
        end
        if context.main_scoring and context.cardarea == G.play and (G.GAME.pool_flags.rolatro_SeekVoucher or false) then
            return {
                chips = 25
            }
        end
    end
}