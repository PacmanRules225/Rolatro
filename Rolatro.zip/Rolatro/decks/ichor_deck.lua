
SMODS.Back {
    key = 'ichor_deck',
    pos = { x = 4, y = 0 },
    config = {
        extra = {
            repetitions = 3
        },
    },
    loc_txt = {
        name = 'Ichor Deck',
        text = {
            [1] = 'Start with {C:attention}3{} random {C:red}Dandy\'s World{} Jokers'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        for i = 1, 3 do
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound('timpani')
                    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                        local new_joker = SMODS.add_card({ set = 'rolatro_dandy' })
                        if new_joker then
                        end
                        G.GAME.joker_buffer = 0
                    end
                    return true
                end
            }))
            
        end
    end
}