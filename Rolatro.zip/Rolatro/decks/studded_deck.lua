
SMODS.Back {
    key = 'studded_deck',
    pos = { x = 2, y = 0 },
    config = {
        extra = {
            all_blinds_size0 = 1.25
        },
    },
    loc_txt = {
        name = 'Studded Deck',
        text = {
            [1] = 'All cards in {C:attention}deck{} are {X:enhanced,C:white}Studded{}.',
            [2] = '{C:attention}All Blind requirements{} are',
            [3] = 'increased by {X:red,C:white}X1.25{}.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.playing_cards) do
                    v:set_ability(G.P_CENTERS['m_rolatro_studded2'])
                end
                G.GAME.starting_deck_size = #G.playing_cards
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            func = function()
                G.GAME.starting_params.ante_scaling = G.GAME.starting_params.ante_scaling * 1.25
                return true
            end
        }))
    end
}