
SMODS.Back {
    key = 'deckfornoobs',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            item_rate0 = 2,
            item_rate = 2,
            odds = 5
        },
    },
    loc_txt = {
        name = 'Deck for Noobs',
        text = {
            [1] = 'Start with {C:tarot}New User{} and {C:money}$8{}.',
            [2] = '{C:green}1 in 5{} chance to also start with {C:tarot}Alt Account{}.',
            [3] = '{C:red}Gears{} and {C:blue}Experiences{} appear {C:green}2x{} more often.',
            [4] = '{C:blue}+1{} hand, {C:red}+1{} discard, {C:attention}+2{} Consumable Slots',
            [5] = 'Beat {C:attention}Ante 4{} to win.'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    apply = function(self, back)
        G.GAME.win_ante = 4
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.starting_params.hands = G.GAME.starting_params.hands + 1
        G.GAME.experience_rate = G.GAME.experience_rate + 2
        G.GAME.gear_rate = G.GAME.gear_rate + 2
        G.GAME.starting_params.consumable_slots = G.GAME.starting_params.consumable_slots + 2
        G.GAME.starting_params.dollars = G.GAME.starting_params.dollars +8
        for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    play_sound('timpani')
                    SMODS.add_card({ set = 'Tarot', key = 'c_rolatro_newuser'
                    })
                    return true
                end
            }))
        end
        if SMODS.pseudorandom_probability(card, 'group_0_edae2ba4', 1, card.ability.extra.odds, 'j_rolatro_deckfornoobs', false) then
            for i = 1, 1 do
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        play_sound('timpani')
                        SMODS.add_card({ set = 'Tarot', key = 'c_rolatro_altaccount'
                        })
                        return true
                    end
                }))
            end
            
        end
    end
}