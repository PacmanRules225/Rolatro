
SMODS.Joker{ --Screech
    key = "screech",
    config = {
        extra = {
            screeched = 0,
            odds = 4,
            mult0 = 6
        }
    },
    loc_txt = {
        ['name'] = 'Screech',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}#5# in #6#{} chance to {C:attention}add{} {C:mult}+6{} Mult before',
            [4] = '{C:red}self destructing{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_screech') 
        return {vars = {card.ability.extra.screeched, new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_8b0e725e', 1, card.ability.extra.odds, 'j_rolatro_screech', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("rolatro_screech")
                            
                            return true
                        end,
                    }))
                    card.ability.extra.screeched = 1
                    SMODS.calculate_effect({mult = 6}, card)
                end
            end
        end
        if context.after and context.cardarea == G.jokers  and not context.blueprint then
            if to_big((card.ability.extra.screeched or 0)) == to_big(1) then
                return {
                    func = function()
                        local target_joker = card
                        
                        if target_joker then
                            target_joker.getting_sliced = true
                            G.E_MANAGER:add_event(Event({
                                func = function()
                                    target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                                    return true
                                end
                            }))
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                        end
                        return true
                    end,
                    extra = {
                        func = function()
                            card.ability.extra.screeched = 1
                            return true
                        end,
                        colour = G.C.BLUE
                    }
                }
            end
        end
    end
}