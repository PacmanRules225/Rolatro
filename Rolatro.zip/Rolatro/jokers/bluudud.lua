SMODS.Joker{ --Bluudud
    key = "bluudud",
    config = {
        extra = {
            odds = 20
        }
    },
    loc_txt = {
        ['name'] = 'Bluudud',
        ['text'] = {
            [1] = '{C:blue}Originated From: Forsaken{}',
            [2] = '{C:white}-{}',
            [3] = '{C:blue}1 in 20{} chance to add a {C:blue}Bluu Seal{}',
            [4] = 'to a {C:blue}scoring card{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 15,
    rarity = "rolatro_bluu",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_forsaken"] = true },
    in_pool = function(self, args)
          return (
          not args 
            
          or args.source == 'sho' or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and G.GAME.pool_flags.rolatro_Forsaken
      end,

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_SEALS["rolatro_bluuseal"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_bluuseal\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_bluudud') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_8af2b986', 1, card.ability.extra.odds, 'j_rolatro_bluudud', false) then
              context.other_card:set_seal("rolatro_bluuseal", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
    end
}