
SMODS.Joker{ --1x1x1x1
    key = "onex",
    config = {
        extra = {
            odds = 4,
            xchips0 = 0,
            xmult0 = 0
        }
    },
    loc_txt = {
        ['name'] = '1x1x1x1',
        ['text'] = {
            [1] = '{C:gold}Exclusive to: 1x1x1x1 Attacks{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}#1# in #2#{} chance to {C:red}nullify{} all {X:chips,C:white}Chips{} and {X:mult,C:white}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "rolatro_exclusive",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_onex') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_99051a19', 1, card.ability.extra.odds, 'j_rolatro_onex', true) then
                    SMODS.calculate_effect({x_chips = 0}, card)
                    SMODS.calculate_effect({Xmult = 0}, card)
                end
            end
        end
    end
}