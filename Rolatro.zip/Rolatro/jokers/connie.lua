
SMODS.Joker{ --Connie
    key = "connie",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Connie',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:attention}Scoring{} {C:enhanced}Glass Cards{} are replaced',
            [4] = 'with {C:dark_edition}Negative Cards{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  and not context.blueprint then
            if SMODS.get_enhancements(context.other_card)["m_glass"] == true then
                local scored_card = context.other_card
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        scored_card:set_ability(G.P_CENTERS.c_base)
                        scored_card:set_edition("e_negative", true)
                        card_eval_status_text(scored_card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.ORANGE})
                        return true
                    end
                }))
            end
        end
    end
}