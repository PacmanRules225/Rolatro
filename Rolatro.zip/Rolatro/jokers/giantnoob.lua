SMODS.Joker{ --Giant Noob
    key = "giantnoob",
    config = {
        extra = {
            jokerseatenchips = 0,
            yes = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'Giant Noob',
        ['text'] = {
            [1] = '{C:green}Originated From: The \"Make a Cake\" Series{}',
            [2] = '{C:white}-{}',
            [3] = '{C:red}Eats{} the {C:attention}Joker to the left{} at the end of the',
            [4] = 'round and adds {C:chips}+20{} Chips for each one eaten.',
            [5] = '{C:inactive}(Currently: {}{C:chips}#1# {}{C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 12,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true },

    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.jokerseatenchips}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.jokerseatenchips
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
            if not ((function()
        return G.jokers.cards[1] == card
    end)()) then
                return {
                    func = function()
                    card.ability.extra.jokerseatenchips = (card.ability.extra.jokerseatenchips) + 20
                    return true
                end,
                    extra = {
                        func = function()
                local my_pos = nil
                for i = 1, #G.jokers.cards do
                    if G.jokers.cards[i] == card then
                        my_pos = i
                        break
                    end
                end
                local target_joker = nil
                if my_pos and my_pos > 1 then
                    local joker = G.jokers.cards[my_pos - 1]
                    if true and not joker.getting_sliced then
                        target_joker = joker
                    end
                end
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Nom!", colour = G.C.RED})
                end
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}