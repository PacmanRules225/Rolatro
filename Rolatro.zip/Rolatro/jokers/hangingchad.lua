
SMODS.Joker{ --Baller
    key = "hangingchad",
    config = {
        extra = {
            scale0 = 1,
            rotation0 = 45,
            repetitions0 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Baller',
        ['text'] = {
            [1] = 'Retrigger the {C:orange}last{} played card used in scoring'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 2,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        play_sound("rolatro_balled")
                        
                        return true
                    end,
                }))
                local target_card = context.other_card
                return {
                    func = function()
                        target_card:juice_up(1, 45)
                        return true
                    end,
                    extra = {
                        repetitions = 1,
                        message = localize('k_again_ex'),
                        colour = G.C.RED
                    }
                }
            end
        end
    end
}