SMODS.Joker{ --c00lkidd
    key = "c00lkidd",
    config = {
        extra = {
            CoolMult = 0,
            mult = 0.5,
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'c00lkidd',
        ['text'] = {
            [1] = '{C:inactive}\"team c00lkidd join today!\"{}',
            [2] = '',
            [3] = 'When a hand is played,',
            [4] = '{C:green}1 in 5{} chance to add a {C:red}c00l Seal{}',
            [5] = 'to a {C:attention}card{}.',
            [6] = '{C:white}-{}',
            [7] = '{C:purple,s:1.4}If Forsaken has been used:{}',
            [8] = '{C:mult}+0.5{} Mult when a card with a {C:attention}c00l Seal{}',
            [9] = 'is played'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_cool",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_myth"] = true, ["rolatro_forsaken"] = true },

    loc_vars = function(self, info_queue, card)
        
        local info_queue_0 = G.P_SEALS["rolatro_coolseal"]
        if info_queue_0 then
            info_queue[#info_queue + 1] = info_queue_0
        else
            error("JOKERFORGE: Invalid key in infoQueues. \"rolatro_coolseal\" isn't a valid Object key, Did you misspell it or forgot a modprefix?")
        end
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_c00lkidd') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card.seal == "Rolatro_coolseal" and (G.GAME.pool_flags.rolatro_Forsaken or false)) then
                return {
                    mult = card.ability.extra.mult
                }
            elseif true then
                if SMODS.pseudorandom_probability(card, 'group_0_c070bb15', 1, card.ability.extra.odds, 'j_rolatro_c00lkidd', false) then
              context.other_card:set_seal("rolatro_coolseal", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "c00l!", colour = G.C.BLUE})
          end
            end
        end
    end
}