
SMODS.Joker{ --The Owl
    key = "theowl",
    config = {
        extra = {
            chips0_min = NaN,
            chips0_max = 30
        }
    },
    loc_txt = {
        ['name'] = 'The Owl',
        ['text'] = {
            [1] = '{C:green}Originated From: 99 Nights in the Forest{}',
            [2] = '{C:white}-{}',
            [3] = 'If {C:attention}Campfire{} is in hand, {C:chips}+10 to 30{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_forestnights"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
                for i, v in pairs(G.jokers.cards) do
                    if v.config.center.key == "j_campfire" then 
                        return true
                    end
                end
            end)() then
                return {
                    chips = pseudorandom('RANGE:10|30', 10, 30)
                }
            end
        end
    end
}