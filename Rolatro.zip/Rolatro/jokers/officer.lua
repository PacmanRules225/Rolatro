
SMODS.Joker{ --Officer
    key = "officer",
    config = {
        extra = {
            blind_size0 = 0.75
        }
    },
    loc_txt = {
        ['name'] = 'Officer',
        ['text'] = {
            [1] = '{C:green}Originated From: Jailbreak{}',
            [2] = '{C:white}-{}',
            [3] = 'Reduces {C:attention}Blind Requirement{} by {C:attention}0.75x{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true, ["rolatro_jailbreak"] = true },
    
    calculate = function(self, card, context)
        if context.setting_blind  then
            return {
                
                func = function()
                    if G.GAME.blind.in_blind then
                        
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "X"..tostring(0.75).." Blind Size", colour = G.C.GREEN})
                        G.GAME.blind.chips = G.GAME.blind.chips * 0.75
                        G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                        G.HUD_blind:recalculate()
                        return true
                    end
                end
            }
        end
    end
}