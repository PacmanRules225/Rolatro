
SMODS.Joker{ --John Doe
    key = "johndoe",
    config = {
        extra = {
            currentmonth = 0,
            currentday = 0,
            xmult0 = 100,
            mult0 = 3.18
        }
    },
    loc_txt = {
        ['name'] = 'John Doe',
        ['text'] = {
            [1] = '{C:inactive}\"DON\'T PLAY ROBLOX ON MARCH 18{}',
            [2] = '{C:inactive}(NOT CLICKBAIT)\"{}',
            [3] = '',
            [4] = '{C:mult}+3.18{} Mult',
            [5] = 'Additional {X:red,C:white}x100{} Mult if the current',
            [6] = 'date is {C:attention}March 18{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true, ["rolatro_myth"] = true, ["rolatro_forsaken"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {os.date("*t", os.time()).month, os.date("*t", os.time()).day}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (to_big(3) == to_big(os.date("*t", os.time()).month) and to_big(18) == to_big(os.date("*t", os.time()).day)) then
                return {
                    Xmult = 100
                }
            else
                return {
                    mult = 3.18
                }
            end
        end
    end
}