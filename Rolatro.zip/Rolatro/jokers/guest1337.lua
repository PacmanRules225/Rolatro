
SMODS.Joker{ --Guest 1337
    key = "guest1337",
    config = {
        extra = {
            LastGuestMult = 6
        }
    },
    loc_txt = {
        ['name'] = 'Guest 1337',
        ['text'] = {
            [1] = '{C:green}Originated From: The Last Guest{}',
            [2] = '{C:white}-{}',
            [3] = '{C:inactive}\"Be strong. Always be strong.\"{}',
            [4] = '{C:mult}+#1#{} Mult',
            [5] = 'Gains {C:mult}+2{} Mult for every card',
            [6] = '{C:attention}destroyed{}',
            [7] = '{C:red}Resets to 6 after every Boss Blind{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 11,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_modern"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.LastGuestMult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                mult = card.ability.extra.LastGuestMult
            }
        end
        if context.remove_playing_cards  then
            return {
                func = function()
                    card.ability.extra.LastGuestMult = (card.ability.extra.LastGuestMult) + 2
                    return true
                end
            }
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            return {
                func = function()
                    card.ability.extra.LastGuestMult = 6
                    return true
                end,
                message = "Reset!"
            }
        end
    end
}