
SMODS.Joker{ --Glisten
    key = "glisten",
    config = {
        extra = {
            GlistenMult = 0,
            glasscardsindeck = 0
        }
    },
    loc_txt = {
        ['name'] = 'Glisten',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+3{} Mult for every {C:enhanced}Glass Card{} in {C:attention}deck{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },
    
    loc_vars = function(self, info_queue, card)
        
    return {vars = {card.ability.extra.GlistenMult, ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if SMODS.has_enhancement(card, 'm_glass') then count = count + 1 end end; return count end)()) * 3}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
            mult = ((function() local count = 0; for _, card in ipairs(G.playing_cards or {}) do if SMODS.has_enhancement(card, 'm_glass') then count = count + 1 end end; return count end)()) * 3
            }
        end
    end
}