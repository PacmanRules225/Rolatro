
SMODS.Joker{ --Blot
    key = "blot",
    config = {
        extra = {
            chips0_min = NaN,
            chips0_max = 500
        }
    },
    loc_txt = {
        ['name'] = 'Blot',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = '{C:chips}spihC{} fo tnuoma {C:attention}modnar{} a seviG',
            [4] = '{C:inactive})005-1+({}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                chips = pseudorandom('RANGE:1|500', 1, 500)
            }
        end
    end
}