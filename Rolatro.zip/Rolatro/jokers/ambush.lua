
SMODS.Joker{ --Ambush
    key = "ambush",
    config = {
        extra = {
            odds = 3,
            repetitions0_min = NaN,
            repetitions0_max = 5
        }
    },
    loc_txt = {
        ['name'] = 'Ambush',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}#1# in #2#{} chance to {C:attention}retrigger{} a',
            [4] = '{C:attention}scoring card{} {C:blue}1-5{} times'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_ambush') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_312a8fe4', 1, card.ability.extra.odds, 'j_rolatro_ambush', false) then
                    
                    return {repetitions = pseudorandom('RANGE:1|5', 1, 5)}
                end
            end
        end
    end
}