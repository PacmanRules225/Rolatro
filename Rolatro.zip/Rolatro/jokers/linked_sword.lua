
SMODS.Joker{ --Linked Sword
    key = "linked_sword",
    config = {
        extra = {
            odds = 10,
            xmult0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Linked Sword',
        ['text'] = {
            [1] = '{C:inactive}\"With blood and iron.\"{}',
            [2] = '',
            [3] = '',
            [4] = '{C:green}#2# in #3#{} chance to {C:attention}Lunge{} and score {X:mult,C:white}X1.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_brickbattle"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_linked_sword') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_d23c0750', 1, card.ability.extra.odds, 'j_rolatro_linked_sword', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("rolatro_swordlunge")
                            
                            return true
                        end,
                    }))
                    SMODS.calculate_effect({Xmult = 1.5}, card)
                end
            end
        end
    end
}