
SMODS.Joker{ --Cart Ride Joker
    key = "cartridejoker",
    config = {
        extra = {
            chips0 = 50
        }
    },
    loc_txt = {
        ['name'] = 'Cart Ride Joker',
        ['text'] = {
            [1] = '{C:chips}+50{} Chips when the Boss Blind is {C:attention}triggered{}',
            [2] = '{C:inactive}(excluding Vanilla Showdown Blinds){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true, ["rolatro_elevator_allowed"] = true },
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (G.GAME.blind.triggered and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_acorn")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_leaf")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_vessel")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_heart")) and not (to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_bell"))) then
                return {
                    chips = 50
                }
            end
        end
    end
}