SMODS.Joker{ --El Goblino & Jeff
    key = "elgoblinojeff",
    config = {
        extra = {
            slot_change = 1
        }
    },
    loc_txt = {
        ['name'] = 'El Goblino & Jeff',
        ['text'] = {
            [1] = '{C:green}Originated From: DOORS{}',
            [2] = '{C:white}-{}',
            [3] = '{C:attention}All slots{} in the {C:attention}shop{} are',
            [4] = 'increased by {C:attention}1{}.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_doors"] = true },

    calculate = function(self, card, context)
    end,

    add_to_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit + card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(1)
        SMODS.change_booster_limit(1)
        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
    end,

    remove_from_deck = function(self, card, from_debuff)
        G.E_MANAGER:add_event(Event({func = function()
            G.consumeables.config.card_limit = G.consumeables.config.card_limit - card.ability.extra.slot_change
            return true
        end }))
        SMODS.change_voucher_limit(-1)
        SMODS.change_booster_limit(-1)
        G.jokers.config.card_limit = G.jokers.config.card_limit - 1
    end
}