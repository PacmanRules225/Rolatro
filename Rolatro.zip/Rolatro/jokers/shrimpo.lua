
SMODS.Joker{ --Shrimpo
    key = "shrimpo",
    config = {
        extra = {
            HateMult = 1
        }
    },
    loc_txt = {
        ['name'] = 'Shrimpo',
        ['text'] = {
            [1] = '{C:green}Originated From: Dandy\'s World{}',
            [2] = '{C:white}-{}',
            [3] = 'Gain {X:mult,C:white}X2.5{} Mult when the Boss Blind is {C:attention}triggered{}',
            [4] = '{C:inactive}(Currently: {}{X:mult,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 17,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_dandy"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {card.ability.extra.HateMult}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.blind.triggered then
                card.ability.extra.HateMult = (card.ability.extra.HateMult) + 2.5
                return {
                    message = "I HATE BOSS BLINDS!"
                }
            elseif to_big((card.ability.extra.HateMult or 0)) ~= to_big(0) then
                return {
                    Xmult = card.ability.extra.HateMult
                }
            end
        end
        if context.setting_blind  then
            if (to_big(G.GAME.blind.config.blind.key) == to_big("bl_wall") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_water") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_manacle") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_needle") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_mark") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_vessel") and to_big(G.GAME.blind.config.blind.key) == to_big("bl_final_bell")) then
                return {
                    func = function()
                        card.ability.extra.HateMult = (card.ability.extra.HateMult) + 2.5
                        return true
                    end,
                    message = "I HATE BOSS BLINDS!"
                }
            end
        end
    end
}