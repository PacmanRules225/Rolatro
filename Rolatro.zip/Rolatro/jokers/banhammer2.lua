
SMODS.Joker{ --Banhammer
    key = "banhammer2",
    config = {
        extra = {
            xmult0 = 3,
            odds = 5
        }
    },
    loc_txt = {
        ['name'] = 'Banhammer',
        ['text'] = {
            [1] = '{C:blue}Based On: Roblox Moderation{}',
            [2] = '{C:white}-{}',
            [3] = '{C:inactive}\"Our content monitors have determined that{}',
            [4] = '{C:inactive}your behavior at ROBLOX has been in violation of{}',
            [5] = '{C:inactive}our Terms of Service.\"{}',
            [6] = '',
            [7] = '{X:mult,C:white}x3{} Mult',
            [8] = '{C:green}#1# in #2#{} chance to instantly',
            [9] = '{C:red}lose the game{}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_epic",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_banhammer2') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if true then
                return {
                    Xmult = 3
                    ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_11a43dda', 1, card.ability.extra.odds, 'j_rolatro_banhammer2', false) then
                            SMODS.calculate_effect({func = function()
                                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Account Terminated", colour = G.C.RED})
                                G.E_MANAGER:add_event(Event({
                                    trigger = 'after',
                                    delay = 0.5,
                                    func = function()
                                        if G.STAGE == G.STAGES.RUN then 
                                            G.STATE = G.STATES.GAME_OVER
                                            G.STATE_COMPLETE = false
                                        end
                                    end
                                }))
                                
                                return true
                            end}, card)
                        end
                        return true
                    end
                }
            end
        end
    end
}