
SMODS.Joker{ --VIP Badge
    key = "vip",
    config = {
        extra = {
            voucher_slots_increase = '2',
            discount_amount = '50',
            dollars0 = 4
        }
    },
    loc_txt = {
        ['name'] = 'VIP Badge',
        ['text'] = {
            [1] = '{C:gold}Exclusive to: VIP Gamepass{}',
            [2] = '{C:white}-{}',
            [3] = '{C:attention}+2 voucher slots{} in {C:attention}shop{}',
            [4] = '{C:attention}All shop items{} are {C:green}50%{} off',
            [5] = '{C:money}+$4{} at the end of a round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 1,
    rarity = "rolatro_exclusive",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    set_ability = function(self, card, initial)
        card:set_eternal(true)
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            return {
                
                func = function()
                    
                    local current_dollars = G.GAME.dollars
                    local target_dollars = G.GAME.dollars + 4
                    local dollar_value = target_dollars - current_dollars
                    ease_dollars(dollar_value)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(4), colour = G.C.MONEY})
                    return true
                end
            }
        end
    end,
    
    add_to_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(2)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.I.CARD) do
                if v.set_cost then v:set_cost() end
                end
                return true
            end
        }))
        G.jokers.config.card_limit = G.jokers.config.card_limit + 1
        -- Showman effect enabled (allow duplicate cards)
    end,
    
    remove_from_deck = function(self, card, from_debuff)
        SMODS.change_voucher_limit(-2)
        G.E_MANAGER:add_event(Event({
            func = function()
                for k, v in pairs(G.I.CARD) do
                if v.set_cost then v:set_cost() end
                end
                return true
            end
        }))
        G.jokers.config.card_limit = G.jokers.config.card_limit - 1
        -- Showman effect disabled
    end
}


local card_set_cost_ref = Card.set_cost
function Card:set_cost()
    card_set_cost_ref(self)
    
    if next(SMODS.find_card("j_rolatro_vip")) then
        if (self.ability.set == 'Joker' or self.ability.set == 'Tarot' or self.ability.set == 'Planet' or self.ability.set == 'Spectral' or self.ability.set == 'Enhanced' or self.ability.set == 'Booster' or self.ability.set == 'Voucher') then
            self.cost = math.max(0, math.floor(self.cost * (1 - (50) / 100)))
        end
    end
    
    self.sell_cost = math.max(1, math.floor(self.cost / 2)) + (self.ability.extra_value or 0)
    self.sell_cost_label = self.facing == 'back' and '?' or self.sell_cost
end
local smods_showman_ref = SMODS.showman
function SMODS.showman(card_key)
    if next(SMODS.find_card("j_rolatro_vip")) then
        return true
    end
    return smods_showman_ref(card_key)
end