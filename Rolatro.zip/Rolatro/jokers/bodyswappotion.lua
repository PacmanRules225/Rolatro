SMODS.Joker{ --Body Swap Potion
    key = "bodyswappotion",
    config = {
        extra = {
            odds = 4,
            rolatro_robass = 0
        }
    },
    loc_txt = {
        ['name'] = 'Body Swap Potion',
        ['text'] = {
            [1] = '{C:green}1 in 4{} chance to swap {C:chips}Chips{} and {C:mult}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_586e7192', 1, card.ability.extra.odds, 'j_rolatro_bodyswappotion', false) then
              play_sound("rolatro_robass")
                        SMODS.calculate_effect({swap = true}, card)
          end
            end
        end
    end
}