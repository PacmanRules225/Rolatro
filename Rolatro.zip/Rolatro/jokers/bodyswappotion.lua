
SMODS.Joker{ --Body Swap Potion
    key = "bodyswappotion",
    config = {
        extra = {
            odds = 4
        }
    },
    loc_txt = {
        ['name'] = 'Body Swap Potion',
        ['text'] = {
            [1] = '{C:green}#2# in #3#{} chance to swap {C:chips}Chips{} and {C:mult}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_elevator_allowed"] = true },
    
    loc_vars = function(self, info_queue, card)
        
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_rolatro_bodyswappotion') 
        return {vars = {new_numerator, new_denominator}}
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  and not context.blueprint then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_586e7192', 1, card.ability.extra.odds, 'j_rolatro_bodyswappotion', false) then
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            play_sound("rolatro_robass")
                            
                            return true
                        end,
                    }))
                    SMODS.calculate_effect({swap = true}, card)
                end
            end
        end
    end
}