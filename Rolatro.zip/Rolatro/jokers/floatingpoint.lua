
SMODS.Joker{ --Floating Point
    key = "floatingpoint",
    config = {
        extra = {
            xmult0_min = NaN,
            xmult0_max = 1000
        }
    },
    loc_txt = {
        ['name'] = 'Floating Point',
        ['text'] = {
            [1] = '{C:gold}Exclusive to: Rolatro Superpack{}',
            [2] = '{C:gold}(very rare chance){}',
            [3] = '{C:white}-{}',
            [4] = '{X:mult,C:white}Xnil{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 30,
    rarity = "rolatro_exclusive",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_nullzone"] = true },
    in_pool = function(self, args)
        return (
            not args 
            or args.source ~= 'sho' and args.source ~= 'buf' and args.source ~= 'jud' 
            or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
        )
        and true
    end,
    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            return {
                Xmult = pseudorandom('RANGE:1|1000', 1, 1000)
            }
        end
    end
}