
SMODS.Joker{ --Tix
    key = "tix",
    config = {
        extra = {
            handsremaining = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tix',
        ['text'] = {
            [1] = '{C:money}+$5{} for each remaining {C:blue}hand{}',
            [2] = 'after the {C:attention}boss blind{} is defeated'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    
    loc_vars = function(self, info_queue, card)
        
        return {vars = {((G.GAME.current_round.hands_left or 0)) * 5}}
    end,
    
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
            if G.GAME.blind.boss then
            end
        end
    end
}