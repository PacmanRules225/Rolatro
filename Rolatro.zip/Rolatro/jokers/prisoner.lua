SMODS.Joker{ --Prisoner
    key = "prisoner",
    config = {
        extra = {
            odds = 5,
            perishable = 0,
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'Prisoner',
        ['text'] = {
            [1] = '{C:green}Originated From: Jailbreak{}',
            [2] = '{C:white}-{}',
            [3] = '{C:green}1 in 5{} chance to get a {C:dark_edition}Perishable{} {C:attention}Burglar{}',
            [4] = 'when {C:attention}selling this Joker{}',
            [5] = '{C:inactive}(Must have room){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = "rolatro_bloxxer",
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true, ["rolatro_jailbreak"] = true },

    calculate = function(self, card, context)
        if context.selling_self  and not context.blueprint then
            if true then
                return {
                    func = function()
                card:undefined()
                return true
            end
                ,
                    func = function()
                        if SMODS.pseudorandom_probability(card, 'group_0_f3fc1f95', 1, card.ability.extra.odds, 'j_rolatro_prisoner', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_burglar' })
                    if joker_card then
                        
                        joker_card:add_sticker('perishable', true)
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
                        return true
                    end
                }
            end
        end
    end
}