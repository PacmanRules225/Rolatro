SMODS.Joker{ --Player (GASA4)
    key = "playergasa4",
    config = {
        extra = {
            currenthours = 0,
            mult = 6,
            Xmult = 2,
            mult2 = 6,
            mult3 = 6
        }
    },
    loc_txt = {
        ['name'] = 'Player (GASA4)',
        ['text'] = {
            [1] = '{C:green}Originated From: get a snack at 4 am{}',
            [2] = '{C:white}-{}',
            [3] = '{C:mult}+6{} Mult if a {C:attention}Rolatro{} {C:attention}Food{} {C:attention}Gear{} is in hand',
            [4] = 'Additional {X:mult,C:white}X2{} Mult if the',
            [5] = '{C:attention}current hour{} is {C:red}4:00 AM{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = "rolatro_bloxxer",
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_getasnack"] = true, ["rolatro_modern"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local count = 0
    for _, consumable_card in pairs(G.consumeables.cards or {}) do
        if consumable_card.config.center.key == "c_rolatro_cheezburger" then
            count = count + 1
        end
    end
    return count >= 1
end)() then
                return {
                    mult = card.ability.extra.mult
                }
            elseif 4 == os.date("*t", os.time()).hour then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            elseif (function()
    local count = 0
    for _, consumable_card in pairs(G.consumeables.cards or {}) do
        if consumable_card.config.center.key == "c_rolatro_spacesandwich" then
            count = count + 1
        end
    end
    return count >= 1
end)() then
                return {
                    mult = card.ability.extra.mult2
                }
            elseif (function()
    local count = 0
    for _, consumable_card in pairs(G.consumeables.cards or {}) do
        if consumable_card.config.center.key == "c_rolatro_pizza" then
            count = count + 1
        end
    end
    return count >= 1
end)() then
                return {
                    mult = card.ability.extra.mult3
                }
            end
        end
    end
}