
SMODS.Booster {
    key = 'retro_pack2',
    loc_txt = {
        name = "Retro Pack",
        text = {
            [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:attention}Rolatro Joker{} cards',
            [2] = 'in the {C:red}Retro{} category.'
        },
        group_name = "Retro Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        local weights = {
            1,
            0.25
        }
        local total_weight = 0
        for _, weight in ipairs(weights) do
            total_weight = total_weight + weight
        end
        local random_value = pseudorandom('rolatro_retro_pack2_card') * total_weight
        local cumulative_weight = 0
        local selected_index = 1
        for j, weight in ipairs(weights) do
            cumulative_weight = cumulative_weight + weight
            if random_value <= cumulative_weight then
                selected_index = j
                break
            end
        end
        if selected_index == 1 then
            return {
                set = "rolatro_retro",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "rolatro_retro_pack2"
            }
        elseif selected_index == 2 then
            return {
                set = "rolatro_retro",
                rarity = "Legendary",
                area = G.pack_cards,
                skip_materialize = true,
                soulable = true,
                key_append = "rolatro_retro_pack2"
            }
        end
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
        end,
    }
    
    
    SMODS.Booster {
        key = 'jumbo_retro_pack2',
        loc_txt = {
            name = "Jumbo Retro Pack",
            text = {
                [1] = 'Choose {C:attention}1{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                [2] = 'in the {C:red}Retro{} category.'
            },
            group_name = "Jumbo Retro Pack"
        },
        config = { extra = 4, choose = 1 },
        cost = 6,
        atlas = "CustomBoosters",
        pos = { x = 1, y = 0 },
        discovered = true,
        loc_vars = function(self, info_queue, card)
            local cfg = (card and card.ability) or self.config
            return {
                vars = { cfg.choose, cfg.extra }
            }
        end,
        create_card = function(self, card, i)
            local weights = {
                1,
                0.25
            }
            local total_weight = 0
            for _, weight in ipairs(weights) do
                total_weight = total_weight + weight
            end
            local random_value = pseudorandom('rolatro_jumbo_retro_pack2_card') * total_weight
            local cumulative_weight = 0
            local selected_index = 1
            for j, weight in ipairs(weights) do
                cumulative_weight = cumulative_weight + weight
                if random_value <= cumulative_weight then
                    selected_index = j
                    break
                end
            end
            if selected_index == 1 then
                return {
                    set = "rolatro_retro",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "rolatro_jumbo_retro_pack2"
                }
            elseif selected_index == 2 then
                return {
                    set = "rolatro_retro",
                    rarity = "Legendary",
                    area = G.pack_cards,
                    skip_materialize = true,
                    soulable = true,
                    key_append = "rolatro_jumbo_retro_pack2"
                }
            end
        end,
        ease_background_colour = function(self)
            ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
            ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
        end,
        particles = function(self)
            -- No particles for joker packs
            end,
        }
        
        
        SMODS.Booster {
            key = 'mega_retro_pack2',
            loc_txt = {
                name = "Mega Retro Pack",
                text = {
                    [1] = 'Choose {C:attention}2{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                    [2] = 'in the {C:red}Retro{} category.'
                },
                group_name = "Mega Retro Pack"
            },
            config = { extra = 4, choose = 2 },
            cost = 8,
            atlas = "CustomBoosters",
            pos = { x = 2, y = 0 },
            discovered = true,
            loc_vars = function(self, info_queue, card)
                local cfg = (card and card.ability) or self.config
                return {
                    vars = { cfg.choose, cfg.extra }
                }
            end,
            create_card = function(self, card, i)
                local weights = {
                    1,
                    0.25
                }
                local total_weight = 0
                for _, weight in ipairs(weights) do
                    total_weight = total_weight + weight
                end
                local random_value = pseudorandom('rolatro_mega_retro_pack2_card') * total_weight
                local cumulative_weight = 0
                local selected_index = 1
                for j, weight in ipairs(weights) do
                    cumulative_weight = cumulative_weight + weight
                    if random_value <= cumulative_weight then
                        selected_index = j
                        break
                    end
                end
                if selected_index == 1 then
                    return {
                        set = "rolatro_retro",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_mega_retro_pack2"
                    }
                elseif selected_index == 2 then
                    return {
                        set = "rolatro_retro",
                        rarity = "Legendary",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_mega_retro_pack2"
                    }
                end
            end,
            ease_background_colour = function(self)
                ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
                ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
            end,
            particles = function(self)
                -- No particles for joker packs
                end,
            }
            
            
            SMODS.Booster {
                key = 'metaverse_pack2',
                loc_txt = {
                    name = "Metaverse Pack",
                    text = {
                        [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:blue}Experience{} cards.'
                    },
                    group_name = "Metaverse Pack"
                },
                config = { extra = 2, choose = 1 },
                atlas = "CustomBoosters",
                pos = { x = 3, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "experience",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_metaverse_pack2"
                    }
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
                    ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'jumbo_metaverse_pack2',
                loc_txt = {
                    name = "Jumbo Metaverse Pack",
                    text = {
                        [1] = 'Choose {C:attention}1{} of up to {C:attention}5{} {C:blue}Experience{} cards.'
                    },
                    group_name = "Jumbo Metaverse Pack"
                },
                config = { extra = 5, choose = 1 },
                cost = 6,
                atlas = "CustomBoosters",
                pos = { x = 4, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "experience",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_jumbo_metaverse_pack2"
                    }
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
                    ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'mega_metaverse_pack2',
                loc_txt = {
                    name = "Mega Metaverse Pack",
                    text = {
                        [1] = 'Choose {C:attention}2{} of up to {C:attention}5{} {C:blue}Experience{} cards.'
                    },
                    group_name = "Mega Metaverse Pack"
                },
                config = { extra = 5, choose = 2 },
                cost = 8,
                atlas = "CustomBoosters",
                pos = { x = 5, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "experience",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_mega_metaverse_pack2"
                    }
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
                    ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'catalog_pack2',
                loc_txt = {
                    name = "Catalog Pack",
                    text = {
                        [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:red}Gear{} cards'
                    },
                    group_name = "Catalog Pack"
                },
                config = { extra = 2, choose = 1 },
                atlas = "CustomBoosters",
                pos = { x = 6, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    local weights = {
                        1,
                        0.5
                    }
                    local total_weight = 0
                    for _, weight in ipairs(weights) do
                        total_weight = total_weight + weight
                    end
                    local random_value = pseudorandom('rolatro_catalog_pack2_card') * total_weight
                    local cumulative_weight = 0
                    local selected_index = 1
                    for j, weight in ipairs(weights) do
                        cumulative_weight = cumulative_weight + weight
                        if random_value <= cumulative_weight then
                            selected_index = j
                            break
                        end
                    end
                    if selected_index == 1 then
                        return {
                            set = "gear",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_catalog_pack2"
                        }
                    elseif selected_index == 2 then
                        return {
                            key = "c_rolatro_taco",
                            set = "Tarot",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_catalog_pack2"
                        }
                    end
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
                    ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'jumbo_catalog_pack2',
                loc_txt = {
                    name = "Jumbo Catalog Pack",
                    text = {
                        [1] = 'Choose {C:attention}1{} of up to {C:attention}5{} {C:red}Gear{} cards'
                    },
                    group_name = "Jumbo Catalog Pack"
                },
                config = { extra = 5, choose = 1 },
                cost = 6,
                atlas = "CustomBoosters",
                pos = { x = 7, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    local weights = {
                        1,
                        0.5
                    }
                    local total_weight = 0
                    for _, weight in ipairs(weights) do
                        total_weight = total_weight + weight
                    end
                    local random_value = pseudorandom('rolatro_jumbo_catalog_pack2_card') * total_weight
                    local cumulative_weight = 0
                    local selected_index = 1
                    for j, weight in ipairs(weights) do
                        cumulative_weight = cumulative_weight + weight
                        if random_value <= cumulative_weight then
                            selected_index = j
                            break
                        end
                    end
                    if selected_index == 1 then
                        return {
                            set = "gear",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_jumbo_catalog_pack2"
                        }
                    elseif selected_index == 2 then
                        return {
                            key = "c_rolatro_taco",
                            set = "Tarot",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_jumbo_catalog_pack2"
                        }
                    end
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
                    ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'mega_catalog_pack2',
                loc_txt = {
                    name = "Mega Catalog Pack",
                    text = {
                        [1] = 'Choose {C:attention}2{} of up to {C:attention}5{} {C:red}Gear{} cards'
                    },
                    group_name = "Mega Catalog Pack"
                },
                config = { extra = 5, choose = 2 },
                cost = 8,
                atlas = "CustomBoosters",
                pos = { x = 8, y = 0 },
                select_card = "consumeables",
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    local weights = {
                        1,
                        0.5
                    }
                    local total_weight = 0
                    for _, weight in ipairs(weights) do
                        total_weight = total_weight + weight
                    end
                    local random_value = pseudorandom('rolatro_mega_catalog_pack2_card') * total_weight
                    local cumulative_weight = 0
                    local selected_index = 1
                    for j, weight in ipairs(weights) do
                        cumulative_weight = cumulative_weight + weight
                        if random_value <= cumulative_weight then
                            selected_index = j
                            break
                        end
                    end
                    if selected_index == 1 then
                        return {
                            set = "gear",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_mega_catalog_pack2"
                        }
                    elseif selected_index == 2 then
                        return {
                            key = "c_rolatro_taco",
                            set = "gear",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_mega_catalog_pack2"
                        }
                    end
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
                    ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
                end,
                particles = function(self)
                    G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                        timer = 0.015,
                        scale = 0.2,
                        initialize = true,
                        lifespan = 1,
                        speed = 1.1,
                        padding = -1,
                        attach = G.ROOM_ATTACH,
                        colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
                        fill = true
                    })
                    G.booster_pack_sparkles.fade_alpha = 1
                    G.booster_pack_sparkles:fade(1, 0)
                end,
            }
            
            
            SMODS.Booster {
                key = 'modern_pack2',
                loc_txt = {
                    name = "Modern Pack",
                    text = {
                        [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:attention}Rolatro Joker{} cards',
                        [2] = 'in the {C:red}Modern{} category.'
                    },
                    group_name = "Modern Pack"
                },
                config = { extra = 2, choose = 1 },
                atlas = "CustomBoosters",
                pos = { x = 9, y = 0 },
                discovered = true,
                loc_vars = function(self, info_queue, card)
                    local cfg = (card and card.ability) or self.config
                    return {
                        vars = { cfg.choose, cfg.extra }
                    }
                end,
                create_card = function(self, card, i)
                    return {
                        set = "rolatro_modern",
                        area = G.pack_cards,
                        skip_materialize = true,
                        soulable = true,
                        key_append = "rolatro_modern_pack2"
                    }
                end,
                ease_background_colour = function(self)
                    ease_colour(G.C.DYN_UI.MAIN, HEX("0049ff"))
                    ease_background_colour({ new_colour = HEX('0049ff'), special_colour = HEX("000000"), contrast = 2 })
                end,
                particles = function(self)
                    -- No particles for joker packs
                    end,
                }
                
                
                SMODS.Booster {
                    key = 'jumbo_modern_pack2',
                    loc_txt = {
                        name = "Jumbo Modern Pack",
                        text = {
                            [1] = 'Choose {C:attention}1{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                            [2] = 'in the {C:red}Modern{} category.'
                        },
                        group_name = "Jumbo Modern Pack"
                    },
                    config = { extra = 4, choose = 1 },
                    cost = 6,
                    atlas = "CustomBoosters",
                    pos = { x = 0, y = 1 },
                    discovered = true,
                    loc_vars = function(self, info_queue, card)
                        local cfg = (card and card.ability) or self.config
                        return {
                            vars = { cfg.choose, cfg.extra }
                        }
                    end,
                    create_card = function(self, card, i)
                        return {
                            set = "rolatro_modern",
                            area = G.pack_cards,
                            skip_materialize = true,
                            soulable = true,
                            key_append = "rolatro_jumbo_modern_pack2"
                        }
                    end,
                    ease_background_colour = function(self)
                        ease_colour(G.C.DYN_UI.MAIN, HEX("0049ff"))
                        ease_background_colour({ new_colour = HEX('0049ff'), special_colour = HEX("000000"), contrast = 2 })
                    end,
                    particles = function(self)
                        -- No particles for joker packs
                        end,
                    }
                    
                    
                    SMODS.Booster {
                        key = 'mega_modern_pack2',
                        loc_txt = {
                            name = "Mega Modern Pack",
                            text = {
                                [1] = 'Choose {C:attention}2{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                                [2] = 'in the {C:red}Modern{} category.'
                            },
                            group_name = "Mega Modern Pack"
                        },
                        config = { extra = 4, choose = 2 },
                        cost = 8,
                        atlas = "CustomBoosters",
                        pos = { x = 1, y = 1 },
                        discovered = true,
                        loc_vars = function(self, info_queue, card)
                            local cfg = (card and card.ability) or self.config
                            return {
                                vars = { cfg.choose, cfg.extra }
                            }
                        end,
                        create_card = function(self, card, i)
                            return {
                                set = "rolatro_retro",
                                area = G.pack_cards,
                                skip_materialize = true,
                                soulable = true,
                                key_append = "rolatro_mega_modern_pack2"
                            }
                        end,
                        ease_background_colour = function(self)
                            ease_colour(G.C.DYN_UI.MAIN, HEX("0049ff"))
                            ease_background_colour({ new_colour = HEX('0049ff'), special_colour = HEX("000000"), contrast = 2 })
                        end,
                        particles = function(self)
                            -- No particles for joker packs
                            end,
                        }
                        
                        
                        SMODS.Booster {
                            key = 'hotel_pack',
                            loc_txt = {
                                name = "Hotel Pack",
                                text = {
                                    [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:attention}Rolatro Joker{} cards',
                                    [2] = 'in the {C:red}DOORS{} category.'
                                },
                                group_name = "Hotel Pack"
                            },
                            config = { extra = 2, choose = 1 },
                            atlas = "CustomBoosters",
                            pos = { x = 2, y = 1 },
                            discovered = true,
                            loc_vars = function(self, info_queue, card)
                                local cfg = (card and card.ability) or self.config
                                return {
                                    vars = { cfg.choose, cfg.extra }
                                }
                            end,
                            create_card = function(self, card, i)
                                return {
                                    set = "rolatro_doors",
                                    area = G.pack_cards,
                                    skip_materialize = true,
                                    soulable = true,
                                    key_append = "rolatro_hotel_pack"
                                }
                            end,
                            ease_background_colour = function(self)
                                ease_colour(G.C.DYN_UI.MAIN, HEX("ffeac8"))
                                ease_background_colour({ new_colour = HEX('ffeac8'), special_colour = HEX("7f3300"), contrast = 2 })
                            end,
                            particles = function(self)
                                -- No particles for joker packs
                                end,
                            }
                            
                            
                            SMODS.Booster {
                                key = 'jumbo_hotel_pack2',
                                loc_txt = {
                                    name = "Jumbo Hotel Pack",
                                    text = {
                                        [1] = 'Choose {C:attention}1{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                                        [2] = 'in the {C:red}DOORS{} category.'
                                    },
                                    group_name = "Jumbo Hotel Pack"
                                },
                                config = { extra = 4, choose = 1 },
                                cost = 6,
                                atlas = "CustomBoosters",
                                pos = { x = 3, y = 1 },
                                discovered = true,
                                loc_vars = function(self, info_queue, card)
                                    local cfg = (card and card.ability) or self.config
                                    return {
                                        vars = { cfg.choose, cfg.extra }
                                    }
                                end,
                                create_card = function(self, card, i)
                                    return {
                                        set = "rolatro_doors",
                                        area = G.pack_cards,
                                        skip_materialize = true,
                                        soulable = true,
                                        key_append = "rolatro_jumbo_hotel_pack2"
                                    }
                                end,
                                ease_background_colour = function(self)
                                    ease_colour(G.C.DYN_UI.MAIN, HEX("ffeac8"))
                                    ease_background_colour({ new_colour = HEX('ffeac8'), special_colour = HEX("7f3300"), contrast = 2 })
                                end,
                                particles = function(self)
                                    -- No particles for joker packs
                                    end,
                                }
                                
                                
                                SMODS.Booster {
                                    key = 'mega_hotel_pack2',
                                    loc_txt = {
                                        name = "Mega Hotel Pack",
                                        text = {
                                            [1] = 'Choose {C:attention}2{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                                            [2] = 'in the {C:red}DOORS{} category.'
                                        },
                                        group_name = "Mega Hotel Pack"
                                    },
                                    config = { extra = 4, choose = 2 },
                                    cost = 8,
                                    atlas = "CustomBoosters",
                                    pos = { x = 4, y = 1 },
                                    discovered = true,
                                    loc_vars = function(self, info_queue, card)
                                        local cfg = (card and card.ability) or self.config
                                        return {
                                            vars = { cfg.choose, cfg.extra }
                                        }
                                    end,
                                    create_card = function(self, card, i)
                                        return {
                                            set = "rolatro_doors",
                                            area = G.pack_cards,
                                            skip_materialize = true,
                                            soulable = true,
                                            key_append = "rolatro_mega_hotel_pack2"
                                        }
                                    end,
                                    ease_background_colour = function(self)
                                        ease_colour(G.C.DYN_UI.MAIN, HEX("ffeac8"))
                                        ease_background_colour({ new_colour = HEX('ffeac8'), special_colour = HEX("7f3300"), contrast = 2 })
                                    end,
                                    particles = function(self)
                                        -- No particles for joker packs
                                        end,
                                    }
                                    
                                    
                                    SMODS.Booster {
                                        key = 'booster2',
                                        loc_txt = {
                                            name = "???",
                                            text = {
                                                [1] = '{C:red}This isn\'t a booster pack.{}'
                                            },
                                            group_name = "rolatro_boosters"
                                        },
                                        config = { extra = 3, choose = 1 },
                                        cost = 10,
                                        weight = 0.05,
                                        atlas = "CustomBoosters",
                                        pos = { x = 5, y = 1 },
                                        group_key = "rolatro_boosters",
                                        draw_hand = true,
                                        discovered = true,
                                        loc_vars = function(self, info_queue, card)
                                            local cfg = (card and card.ability) or self.config
                                            return {
                                                vars = { cfg.choose, cfg.extra }
                                            }
                                        end,
                                        create_card = function(self, card, i)
                                            return {
                                                set = "Playing Card",
                                                enhancement = "m_rolatro_seek",
                                                area = G.pack_cards,
                                                skip_materialize = true,
                                                soulable = true,
                                                key_append = "rolatro_booster2"
                                            }
                                        end,
                                        ease_background_colour = function(self)
                                            ease_colour(G.C.DYN_UI.MAIN, HEX("000000"))
                                            ease_background_colour({ new_colour = HEX('000000'), special_colour = HEX("000000"), contrast = 2 })
                                        end,
                                        particles = function(self)
                                            G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
                                                timer = 0.015,
                                                scale = 0.3,
                                                initialize = true,
                                                lifespan = 3,
                                                speed = 0.2,
                                                padding = -1,
                                                attach = G.ROOM_ATTACH,
                                                colours = { G.C.BLACK, G.C.RED },
                                                fill = true
                                            })
                                            G.booster_pack_sparkles.fade_alpha = 1
                                            G.booster_pack_sparkles:fade(1, 0)
                                        end,
                                    }
                                    
                                    
                                    SMODS.Booster {
                                        key = 'gardenview_pack',
                                        loc_txt = {
                                            name = "Gardenview Pack",
                                            text = {
                                                [1] = 'Choose {C:attention}1{} of up to {C:attention}2{} {C:attention}Rolatro Joker{} cards',
                                                [2] = 'in the {C:red}Dandy\'s World{} category.'
                                            },
                                            group_name = "Gardenview Pack"
                                        },
                                        config = { extra = 2, choose = 1 },
                                        atlas = "CustomBoosters",
                                        pos = { x = 6, y = 1 },
                                        discovered = true,
                                        loc_vars = function(self, info_queue, card)
                                            local cfg = (card and card.ability) or self.config
                                            return {
                                                vars = { cfg.choose, cfg.extra }
                                            }
                                        end,
                                        create_card = function(self, card, i)
                                            return {
                                                set = "rolatro_dandy",
                                                area = G.pack_cards,
                                                skip_materialize = true,
                                                soulable = true,
                                                key_append = "rolatro_gardenview_pack"
                                            }
                                        end,
                                        ease_background_colour = function(self)
                                            ease_colour(G.C.DYN_UI.MAIN, HEX("ff8686"))
                                            ease_background_colour({ new_colour = HEX('ff8686'), special_colour = HEX("ba7eff"), contrast = 2 })
                                        end,
                                        particles = function(self)
                                            -- No particles for joker packs
                                            end,
                                        }
                                        
                                        
                                        SMODS.Booster {
                                            key = 'jumbo_gardenview_pack',
                                            loc_txt = {
                                                name = "Jumbo Gardenview Pack",
                                                text = {
                                                    [1] = 'Choose {C:attention}1{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                                                    [2] = 'in the {C:red}Dandy\'s World{} category.'
                                                },
                                                group_name = "Jumbo Gardenview Pack"
                                            },
                                            config = { extra = 4, choose = 1 },
                                            cost = 6,
                                            atlas = "CustomBoosters",
                                            pos = { x = 7, y = 1 },
                                            discovered = true,
                                            loc_vars = function(self, info_queue, card)
                                                local cfg = (card and card.ability) or self.config
                                                return {
                                                    vars = { cfg.choose, cfg.extra }
                                                }
                                            end,
                                            create_card = function(self, card, i)
                                                return {
                                                    set = "rolatro_dandy",
                                                    area = G.pack_cards,
                                                    skip_materialize = true,
                                                    soulable = true,
                                                    key_append = "rolatro_jumbo_gardenview_pack"
                                                }
                                            end,
                                            ease_background_colour = function(self)
                                                ease_colour(G.C.DYN_UI.MAIN, HEX("ff8686"))
                                                ease_background_colour({ new_colour = HEX('ff8686'), special_colour = HEX("ba7eff"), contrast = 2 })
                                            end,
                                            particles = function(self)
                                                -- No particles for joker packs
                                                end,
                                            }
                                            
                                            
                                            SMODS.Booster {
                                                key = 'mega_gardenview_pack',
                                                loc_txt = {
                                                    name = "Mega Gardenview Pack",
                                                    text = {
                                                        [1] = 'Choose {C:attention}2{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards',
                                                        [2] = 'in the {C:red}Dandy\'s World{} category.'
                                                    },
                                                    group_name = "Mega Gardenview Pack"
                                                },
                                                config = { extra = 4, choose = 2 },
                                                cost = 8,
                                                atlas = "CustomBoosters",
                                                pos = { x = 8, y = 1 },
                                                discovered = true,
                                                loc_vars = function(self, info_queue, card)
                                                    local cfg = (card and card.ability) or self.config
                                                    return {
                                                        vars = { cfg.choose, cfg.extra }
                                                    }
                                                end,
                                                create_card = function(self, card, i)
                                                    return {
                                                        set = "rolatro_dandy",
                                                        area = G.pack_cards,
                                                        skip_materialize = true,
                                                        soulable = true,
                                                        key_append = "rolatro_mega_gardenview_pack"
                                                    }
                                                end,
                                                ease_background_colour = function(self)
                                                    ease_colour(G.C.DYN_UI.MAIN, HEX("ff8686"))
                                                    ease_background_colour({ new_colour = HEX('ff8686'), special_colour = HEX("ba7eff"), contrast = 2 })
                                                end,
                                                particles = function(self)
                                                    -- No particles for joker packs
                                                    end,
                                                }
                                                
                                                
                                                SMODS.Booster {
                                                    key = 'rolatro_superpack',
                                                    loc_txt = {
                                                        name = "Rolatro Superpack",
                                                        text = {
                                                            [1] = 'Choose {C:attention}2{} of up to {C:attention}4{} {C:attention}Rolatro Joker{} cards.',
                                                            [2] = 'Contains nearly {C:attention}every single{} Rolatro Joker.'
                                                        },
                                                        group_name = "rolatro_boosters"
                                                    },
                                                    config = { extra = 4, choose = 2 },
                                                    cost = 9,
                                                    atlas = "CustomBoosters",
                                                    pos = { x = 9, y = 1 },
                                                    group_key = "rolatro_boosters",
                                                    discovered = true,
                                                    loc_vars = function(self, info_queue, card)
                                                        local cfg = (card and card.ability) or self.config
                                                        return {
                                                            vars = { cfg.choose, cfg.extra }
                                                        }
                                                    end,
                                                    create_card = function(self, card, i)
                                                        local weights = {
                                                            4.95,
                                                            0.05
                                                        }
                                                        local total_weight = 0
                                                        for _, weight in ipairs(weights) do
                                                            total_weight = total_weight + weight
                                                        end
                                                        local random_value = pseudorandom('rolatro_rolatro_superpack_card') * total_weight
                                                        local cumulative_weight = 0
                                                        local selected_index = 1
                                                        for j, weight in ipairs(weights) do
                                                            cumulative_weight = cumulative_weight + weight
                                                            if random_value <= cumulative_weight then
                                                                selected_index = j
                                                                break
                                                            end
                                                        end
                                                        if selected_index == 1 then
                                                            return {
                                                                set = "rolatro_rolatro_jokers",
                                                                area = G.pack_cards,
                                                                skip_materialize = true,
                                                                soulable = true,
                                                                key_append = "rolatro_rolatro_superpack"
                                                            }
                                                        elseif selected_index == 2 then
                                                            return {
                                                                key = "j_rolatro_floatingpoint",
                                                                set = "Joker",
                                                                area = G.pack_cards,
                                                                skip_materialize = true,
                                                                soulable = true,
                                                                key_append = "rolatro_rolatro_superpack"
                                                            }
                                                        end
                                                    end,
                                                    ease_background_colour = function(self)
                                                        ease_colour(G.C.DYN_UI.MAIN, HEX("0066ff"))
                                                        ease_background_colour({ new_colour = HEX('0066ff'), special_colour = HEX("ff0000"), contrast = 2 })
                                                    end,
                                                    particles = function(self)
                                                        -- No particles for joker packs
                                                        end,
                                                    }
                                                    