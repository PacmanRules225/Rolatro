SMODS.Consumable {
    key = 'starterplace',
    set = 'experience',
    pos = { x = 1, y = 2 },
    loc_txt = {
        name = 'Starter Place',
        text = {
        [1] = '{C:inactive}\"Your very first Roblox creation.\"{}',
        [2] = '',
        [3] = 'Gives an {C:uncommon}Uncommon Tag{} upon being consumed.'
    }
    },
    cost = 2,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                func = function()
                    local tag = Tag("tag_uncommon")
                    if tag.name == "Orbital Tag" then
                        local _poker_hands = {}
                        for k, v in pairs(G.GAME.hands) do
                            if v.visible then
                                _poker_hands[#_poker_hands + 1] = k
                            end
                        end
                        tag.ability.orbital_hand = pseudorandom_element(_poker_hands, "jokerforge_orbital")
                    end
                    tag:set_ability()
                    add_tag(tag)
                    play_sound('holo1', 1.2 + math.random() * 0.1, 0.4)
                    return true
                end
            }))
    end,
    can_use = function(self, card)
        return true
    end
}