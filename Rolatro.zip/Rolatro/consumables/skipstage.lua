
SMODS.Consumable {
    key = 'skipstage',
    set = 'gamepass',
    pos = { x = 8, y = 4 },
    loc_txt = {
        name = 'Skip Stage',
        text = {
            [1] = 'Instantly {C:green}win{} the current {C:attention}non-boss blind{}!',
            [2] = 'This only works if the blind is {C:red}not{} a',
            [3] = '{C:attention}boss blind{}.'
        }
    },
    cost = 30,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
            G.E_MANAGER:add_event(Event({
                func = function()
                    G.GAME.blind:disable()
                    play_sound('timpani')
                    return true
                end
            }))
            card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "Boss Blind Disabled!", colour = G.C.GREEN})
        end
        if not (G.GAME.blind.boss) then
            G.E_MANAGER:add_event(Event({
                blocking = false,
                func = function()
                    if G.STATE == G.STATES.SELECTING_HAND then
                        G.GAME.chips = G.GAME.blind.chips
                        G.STATE = G.STATES.HAND_PLAYED
                        G.STATE_COMPLETE = true
                        end_round()
                        return true
                    end
                end
            }))
            return {
                message = "Win!"
            }
        end
    end,
    can_use = function(self, card)
        return (not (G.GAME.blind.boss))
    end
}