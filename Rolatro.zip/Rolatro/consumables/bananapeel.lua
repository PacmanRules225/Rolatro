
SMODS.Consumable {
    key = 'bananapeel',
    set = 'gear',
    pos = { x = 1, y = 5 },
    config = { 
        extra = {
            odds = 4,
            odds = 2,
            hands0 = 1   
        } 
    },
    loc_txt = {
        name = 'Banana Peel',
        text = {
            [1] = '{C:green}1 in 4{} chance to',
            [2] = 'disable the current {C:attention}boss blind{},',
            [3] = 'but {C:green}1 in 2{} chance to {C:red}lose 1{} {C:blue}Hand{}',
            [4] = 'for this round'
        }
    },
    cost = 5,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if SMODS.pseudorandom_probability(card, 'group_0_965b312a', 1, card.ability.extra.odds, 'j_rolatro_bananapeel', false) then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("rolatro_slip")
                    
                    return true
                end,
            }))
            if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.blind:disable()
                        play_sound('timpani')
                        return true
                    end
                }))
                card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
            end
            
        end
        if SMODS.pseudorandom_probability(card, 'group_0_6a7dc626', 1, card.ability.extra.odds2, 'j_rolatro_bananapeel', false) then
            G.E_MANAGER:add_event(Event({
                func = function()
                    play_sound("rolatro_slip")
                    
                    return true
                end,
            }))
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "-"..tostring(1).." Hands", colour = G.C.RED})
                    G.GAME.current_round.hands_left = G.GAME.current_round.hands_left - 1
                    return true
                end
            }))
            delay(0.6)
            
        end
    end,
    can_use = function(self, card)
        return true
    end
}