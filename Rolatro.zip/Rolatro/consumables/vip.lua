
SMODS.Consumable {
    key = 'vip',
    set = 'gamepass',
    pos = { x = 4, y = 4 },
    loc_txt = {
        name = 'VIP',
        text = {
            [1] = 'Creates an {C:purple}Eternal{} VIP Badge {C:attention}Joker{}',
            [2] = '{C:inactive}(no need to make room){}',
            [3] = '{C:white}-{}',
            [4] = '{C:red}After use, this gamepass will{}',
            [5] = '{C:red}no longer appear in the run.{}'
        }
    },
    cost = 35,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_vip' })
                if new_joker then
                end
                used_card:juice_up(0.3, 0.5)
                return true
            end
        }))
        delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}