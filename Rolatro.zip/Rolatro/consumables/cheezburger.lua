SMODS.Consumable {
    key = 'cheezburger',
    set = 'gear',
    pos = { x = 3, y = 0 },
    config = { extra = {
        hands_value = 1
    } },
    loc_txt = {
        name = 'Cheezburger ',
        text = {
        [1] = '{C:inactive}\"Can I haz cheezburger plz?\"{}',
        [2] = '',
        [3] = 'Adds {C:attention}1{} {C:blue}hand{} for {C:attention}this round{}.'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        if G.GAME.blind.in_blind then
            play_sound("rolatro_mmmchezburger")
    SMODS.calculate_effect({message = "Mmm, cheezburger!"}, card)
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(1).." Hand", colour = G.C.GREEN})
                    G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + 1
                    return true
                end
            }))
            delay(0.6)
        end
    end,
    can_use = function(self, card)
        return (G.GAME.blind.in_blind)
    end
}