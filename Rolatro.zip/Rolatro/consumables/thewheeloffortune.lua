
SMODS.Consumable {
    key = 'thewheeloffortune',
    set = 'gamepass',
    pos = { x = 9, y = 4 },
    loc_txt = {
        name = 'Wheel of True Fortune',
        text = {
            [1] = '{C:green}Guaranteed{} chance to add {C:dark_edition}Foil{}, {C:dark_edition}Holographic{},',
            [2] = 'or {C:dark_edition}Polychrome{} edition to a random {C:attention}Joker{}'
        }
    },
    cost = 20,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        local index = math.random(1, #G.jokers.cards)
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                used_card:juice_up(0.3, 0.5)
                return true
            end
        }))
        local percent = 1.15 - (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.15,
            func = function()
                
                G.jokers.cards[index]:flip()
                play_sound('card1', percent)
                G.jokers.cards[index]:juice_up(0.3, 0.3)
                return true
            end
        }))
        delay(0.2)
        
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.1,
            func = function()
                
                local edition = pseudorandom_element({'e_foil','e_holo','e_polychrome','e_negative','e_rolatro_subspaced','e_rolatro_hacked'}, 'random edition')
                G.jokers.cards[index]:set_edition(edition, true)
                return true
            end
        }))
        
        local percent = 0.85 + (i - 0.999) / (#G.hand.highlighted - 0.998) * 0.3
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.15,
            func = function()
                G.jokers.cards[index]:flip()
                play_sound('tarot2', percent, 0.6)
                G.jokers.cards[index]:juice_up(0.3, 0.3)
                return true
            end
        }))
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.2,
            func = function()
                G.jokers:unhighlight_all()
                return true
            end
        }))
        delay(0.5)
        return {
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    attention_text({
                        text = "Yup!",
                        scale = 1.3,
                        hold = 1.4,
                        major = card,
                        backdrop_colour = G.C.GREEN,
                        align = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK or G.STATE == G.STATES.SMODS_BOOSTER_OPENED) and
                        'tm' or 'cm',
                        offset = { x = 0, y = (G.STATE == G.STATES.TAROT_PACK or G.STATE == G.STATES.SPECTRAL_PACK or G.STATE == G.STATES.SMODS_BOOSTER_OPENED) and -0.2 or 0 },
                        silent = false,
                    })
                    G.E_MANAGER:add_event(Event({
                        trigger = 'after',
                        delay = 0.06 * G.SETTINGS.GAMESPEED,
                        blockable = false,
                        blocking = false,
                        func = function()
                            play_sound('tarot2', 0.76, 0.4)
                            return true
                        end
                    }))
                    play_sound('tarot2', 1, 0.4)
                    card:juice_up(0.3, 0.5)
                    return true
                end
            }))
        }
    end,
    can_use = function(self, card)
        return true
    end
}