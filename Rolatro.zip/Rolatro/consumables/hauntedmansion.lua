
SMODS.Consumable {
    key = 'hauntedmansion',
    set = 'experience',
    pos = { x = 6, y = 3 },
    config = { 
        extra = {
            odds = 4   
        } 
    },
    loc_txt = {
        name = 'Haunted Mansion',
        text = {
            [1] = 'Spawns either {C:attention}Zombie{}, {C:attention}Skeleton{},',
            [2] = 'or {C:attention}Headless Horseman{}.',
            [3] = '{C:green}1 in 4{} chance to create an',
            [4] = 'additional {C:dark_edition}Negative Edition{} of {C:attention}one of{}',
            [5] = '{C:attention}the above{}',
            [6] = '{C:inactive}(must have room){}'
        }
    },
    cost = 6,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
        G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
                play_sound('timpani')
                if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
                    G.GAME.joker_buffer = G.GAME.joker_buffer + 1
                    local new_joker = SMODS.add_card({ set = 'rolatro_mansion' })
                    if new_joker then
                    end
                    G.GAME.joker_buffer = 0
                end
                used_card:juice_up(0.3, 0.5)
                return true
            end
        }))
        delay(0.6)
        if SMODS.pseudorandom_probability(card, 'group_0_348d2aa9', 1, card.ability.extra.odds, 'j_rolatro_hauntedmansion', false) then
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    local new_joker = SMODS.add_card({ set = 'rolatro_mansion' })
                    if new_joker then
                        new_joker:set_edition("e_negative", true)
                    end
                    used_card:juice_up(0.3, 0.5)
                    return true
                end
            }))
            delay(0.6)
            
        end
    end,
    can_use = function(self, card)
        return true
    end
}