SMODS.Consumable {
    key = 'hauntedmansion',
    set = 'experience',
    pos = { x = 0, y = 0 },
    config = { extra = {
        add_cards_count = 2
    } },
    loc_txt = {
        name = ' Haunted Mansion',
        text = {
        [1] = '{C:inactive}\"A map Shedletsky made for Halloween 2006.\"{}',
        [2] = 'Adds {C:attention}2{} {C:green}Zombified{} {C:attention}playing cards{} to deck'
    }
    },
    cost = 4,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.7,
                func = function()
                    local cards = {}
                    for i = 1, 2 do
                        local _rank = pseudorandom_element(SMODS.Ranks, 'add_random_rank').card_key
                        local _suit = nil
                        local new_card_params = { set = "Base" }
                        if _rank then new_card_params.rank = _rank end
                        if _suit then new_card_params.suit = _suit end
                        cards[i] = SMODS.add_card(new_card_params)
                        if cards[i] then
                            cards[i]:set_edition({ foil = true }, true)
                        end
                    end
                    SMODS.calculate_context({ playing_card_added = true, cards = cards })
                    return true
                end
            }))
            delay(0.3)
    end,
    can_use = function(self, card)
        return true
    end
}