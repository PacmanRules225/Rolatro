
SMODS.Shader({ key = 'sepia', path = 'sepia.fs' })

SMODS.Edition {
    key = 'subspaced',
    shader = 'sepia',
    config = {
        extra = {
            xchips0 = 1.3
        }
    },
    in_shop = false,
    extra_cost = 3,
    apply_to_float = true,
    badge_colour = HEX('ff00ff'),
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Subspaced',
        label = 'Subspaced',
        text = {
            [1] = '{X:chips,C:white}X1.3{} Chips'
        }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
    
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return {
                x_chips = 1.3
            }
        end
    end
}