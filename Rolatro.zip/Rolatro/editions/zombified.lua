SMODS.Shader({ key = 'monochrome', path = 'monochrome.fs' })

SMODS.Edition {
    key = 'zombified',
    shader = 'monochrome',
    config = {
        extra = {
            x_mult = 0.9,
            odds = 10
        }
    },
    in_shop = false,
    apply_to_float = false,
    badge_colour = HEX('007a02'),
    sound = { sound = "generic1", per = 1.2, vol = 0.4 },
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Zombified',
        label = 'Zombified',
        text = {
        [1] = '{X:mult,C:white}X0.9{} Mult',
        [2] = '{C:green}1 in 10{} chance to get {C:green}disinfected{}'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
  
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            if SMODS.pseudorandom_probability(card, 'group_0_438e08b4', 1, card.ability.extra.odds, 'm_rolatro_zombified') then
                card:set_edition(nil)
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Disinfected!", colour = G.C.BLUE})
            end
            return { x_mult = card.edition.extra.x_mult }
        end
    end
}