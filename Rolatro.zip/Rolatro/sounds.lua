SMODS.Sound{
    key="oof",
    path="oof.ogg",
    pitch=1,
    volume=0.7
}

SMODS.Sound{
    key="swordlunge",
    path="swordlunge.ogg",
    pitch=1,
    volume=0.9
}

SMODS.Sound{
    key="mmmchezburger",
    path="mmmchezburger.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="rocket",
    path="rocket.ogg",
    pitch=1,
    volume=0.5
}

SMODS.Sound{
    key="subspaceboom",
    path="subspaceboom.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="robass",
    path="robass.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="subspace_bought",
    path="subspace_bought.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="noobini",
    path="noobini.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="gravcoil",
    path="gravcoil.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="speedcoil",
    path="speedcoil.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="cash",
    path="cash.ogg",
    pitch=1,
    volume=0.6
}

SMODS.Sound{
    key="screech_pst",
    path="screech_pst.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="screech",
    path="screech.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="ambush-trigger",
    path="ambush-trigger.ogg",
    pitch=1,
    volume=0.8
}

SMODS.Sound{
    key="nom",
    path="nom.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="colasip",
    path="colasip.ogg",
    pitch=1,
    volume=1
}

SMODS.Sound{
    key="rainingtacos",
    path="rainingtacos.ogg",
    pitch=1,
    volume=0.5
}