SMODS.Joker{ --UGC Joker
    key = "ugcjoker",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'UGC Joker',
        ['text'] = {
            [1] = '{C:mult}+2.5{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true }
}