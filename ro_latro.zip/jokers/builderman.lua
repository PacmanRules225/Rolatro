SMODS.Joker{ --Builderman
    key = "builderman",
    config = {
        extra = {
            odds = 5,
            odds2 = 10,
            odds3 = 15
        }
    },
    loc_txt = {
        ['name'] = 'Builderman',
        ['text'] = {
            [1] = '{C:green}1 in 5{} chance to add',
            [2] = '{C:attention}Builder\'s Club{} to',
            [3] = 'a {C:attention}scored playing card{}',
            [4] = '{C:white}----{}',
            [5] = '{C:green}1 in 10{} chance to add',
            [6] = '{C:attention}Turbo Builder\'s Club{} to',
            [7] = 'a {C:attention}scored playing card{}',
            [8] = '{C:white}----{}',
            [9] = '{C:green}1 in 15{} chance to add',
            [10] = '{C:attention}Outrageous Builder\'s Club{} to a',
            [11] = '{C:attention}scored playing card{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 16,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_6dd87595', 1, card.ability.extra.odds, 'j_rolatro_builderman', false) then
              context.other_card:set_seal("rolatro_bc", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
                if SMODS.pseudorandom_probability(card, 'group_1_f10d2f31', 1, card.ability.extra.odds2, 'j_rolatro_builderman', false) then
              context.other_card:set_seal("rolatro_tbc", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
                if SMODS.pseudorandom_probability(card, 'group_2_9f5f5a2b', 1, card.ability.extra.odds3, 'j_rolatro_builderman', false) then
              context.other_card:set_seal("rolatro_obc", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Card Modified!", colour = G.C.BLUE})
          end
            end
        end
    end
}