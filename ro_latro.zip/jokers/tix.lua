SMODS.Joker{ --Tix
    key = "tix",
    config = {
        extra = {
            tix = 0,
            scale = 1,
            rotation = 1,
            sell_value = 1,
            constant = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tix',
        ['text'] = {
            [1] = 'At the end of every round, gain {C:attention}10{} Tix.',
            [2] = 'Sell this Joker to convert',
            [3] = 'the earned Tix to {C:attention}Money{}.',
            [4] = '{C:inactive}(10 Tix >{} {C:money}$1{}{C:inactive}){}',
            [5] = 'Current Tix: {C:attention}#1#0{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_retro"] = true },

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.tix}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  and not context.blueprint then
                local target_card = context.other_card
      local function juice_card_until_(card, eval_func, first, delay) -- balatro function doesn't allow for custom scale and rotation
          G.E_MANAGER:add_event(Event({
              trigger = 'after',delay = delay or 0.1, blocking = false, blockable = false, timer = 'REAL',
              func = (function() if eval_func(card) then if not first or first then card:juice_up(card.ability.extra.scale, card.ability.extra.rotation) end;juice_card_until_(card, eval_func, nil, 0.8) end return true end)
          }))
      end
                return {
                    func = function()
                        local eval = function() return not G.RESET_JIGGLES end
                        juice_card_until_(card, eval, true)
                        return true
                    end,
                    extra = {
                        func = function()for i, target_card in ipairs(area.cards) do
                if target_card.set_cost then
            target_joker.ability.extra_value = (card.ability.extra_value or 0) + card.ability.extra.sell_value
            target_joker:set_cost()
            end
        end
                    return true
                end,
                            message = "undefined+"..tostring(card.ability.extra.sell_value).." Sell Value",
                        colour = G.C.MONEY,
                        extra = {
                            func = function()
                    card.ability.extra.tix = (card.ability.extra.tix) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
        end
        if context.selling_self  and not context.blueprint then
                return {
                    func = function()
                    card.ability.extra.tix = 0
                    return true
                end
                }
        end
    end
}