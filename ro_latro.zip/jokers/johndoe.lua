SMODS.Joker{ --John Doe
    key = "johndoe",
    config = {
        extra = {
            currentmonth = 0,
            currentday = 0,
            Xmult = 50,
            mult = 3.18
        }
    },
    loc_txt = {
        ['name'] = 'John Doe',
        ['text'] = {
            [1] = '{C:inactive}\"DON\'T PLAY ROBLOX ON MARCH 18{}',
            [2] = '{C:inactive}(NOT CLICKBAIT)\"{}',
            [3] = '',
            [4] = '{C:mult}+3.18{} Mult',
            [5] = 'Additional {X:red,C:white}x50{} Mult if the current',
            [6] = 'date is {C:attention}March 18{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["rolatro_rolatro_jokers"] = true, ["rolatro_roblox"] = true, ["rolatro_modern"] = true, ["rolatro_myth"] = true },

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (3 == os.date("*t", os.time()).month and 18 == os.date("*t", os.time()).day) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            else
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
    end
}