SMODS.Booster {
    key = 'catalog_pack',
    loc_txt = {
        name = "Catalog Pack",
        text = {
            "Choose 1 of up to 2 Gear cards"
        },
        group_name = "Catalog Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "gear",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_catalog_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
        ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'jumbo_catalog_pack',
    loc_txt = {
        name = "Jumbo Catalog Pack",
        text = {
            "Choose 1 of up to 5 Gear cards"
        },
        group_name = "Jumbo Catalog Pack"
    },
    config = { extra = 5, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "gear",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_jumbo_catalog_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
        ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'jumbo_metaverse_pack',
    loc_txt = {
        name = "Jumbo Metaverse Pack",
        text = {
            "Choose 1 of up to 5 Experience cards."
        },
        group_name = "Jumbo Metaverse Pack"
    },
    config = { extra = 5, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "experience",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_jumbo_metaverse_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
        ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'jumbo_modern_pack',
    loc_txt = {
        name = "Jumbo Modern Pack",
        text = {
            "Choose 1 of up to 4 Rolatro Joker cards",
            "in the Modern category."
        },
        group_name = "Jumbo Modern Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 3, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_modern",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_jumbo_modern_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'jumbo_retro_pack',
    loc_txt = {
        name = "Jumbo Retro Pack",
        text = {
            "Choose 1 of up to 4 Rolatro Joker cards",
            "in the Retro category."
        },
        group_name = "Jumbo Retro Pack"
    },
    config = { extra = 4, choose = 1 },
    cost = 6,
    atlas = "CustomBoosters",
    pos = { x = 4, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_retro",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_jumbo_retro_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_catalog_pack',
    loc_txt = {
        name = "Mega Catalog Pack",
        text = {
            "Choose 2 of up to 5 Gear cards"
        },
        group_name = "Mega Catalog Pack"
    },
    config = { extra = 5, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 5, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "gear",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_mega_catalog_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("9b9b9b"))
        ease_background_colour({ new_colour = HEX('9b9b9b'), special_colour = HEX("4a4a4a"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'mega_metaverse_pack',
    loc_txt = {
        name = "Mega Metaverse Pack",
        text = {
            "Choose 2 of up to 5 Experience cards."
        },
        group_name = "Mega Metaverse Pack"
    },
    config = { extra = 5, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 6, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "experience",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_mega_metaverse_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
        ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'mega_modern_pack',
    loc_txt = {
        name = "Mega Modern Pack",
        text = {
            "Choose 2 of up to 4 Rolatro Joker cards",
            "in the Modern category."
        },
        group_name = "Mega Modern Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 7, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_retro",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_mega_modern_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'mega_retro_pack',
    loc_txt = {
        name = "Mega Retro Pack",
        text = {
            "Choose 2 of up to 4 Rolatro Joker cards",
            "in the Retro category."
        },
        group_name = "Mega Retro Pack"
    },
    config = { extra = 4, choose = 2 },
    cost = 8,
    atlas = "CustomBoosters",
    pos = { x = 8, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_retro",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_mega_retro_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'metaverse_pack',
    loc_txt = {
        name = "Metaverse Pack",
        text = {
            "Choose 1 of up to 2 Experience cards."
        },
        group_name = "Metaverse Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 9, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "experience",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_metaverse_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("0041ad"))
        ease_background_colour({ new_colour = HEX('0041ad'), special_colour = HEX("001a46"), contrast = 2 })
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'modern_pack',
    loc_txt = {
        name = "Modern Pack",
        text = {
            "Choose 1 of up to 2 Rolatro Joker cards",
            "in the Modern category."
        },
        group_name = "Modern Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 0, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_modern",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_modern_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'retro_pack',
    loc_txt = {
        name = "Retro Pack",
        text = {
            "Choose 1 of up to 2 Rolatro Joker cards",
            "in the Retro category."
        },
        group_name = "Retro Pack"
    },
    config = { extra = 2, choose = 1 },
    atlas = "CustomBoosters",
    pos = { x = 1, y = 1 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "rolatro_retro",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "rolatro_retro_pack"
        }
    end,
    ease_background_colour = function(self)
        ease_colour(G.C.DYN_UI.MAIN, HEX("ff0000"))
        ease_background_colour({ new_colour = HEX('ff0000'), special_colour = HEX("000000"), contrast = 2 })
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}
