SMODS.Consumable {
    key = 'petsimulator99',
    set = 'experience',
    pos = { x = 2, y = 1 },
    config = { extra = {
        odds = 1000
    } },
    loc_txt = {
        name = 'Pet Simulator 99',
        text = {
        [1] = '{C:inactive}\"Keep hatching for that HUGE!\"{}',
        [2] = '',
        [3] = '{C:green}1 in ???{} chance to get the {C:attention}HUGE Joker Pet{}',
        [4] = '{C:inactive}(You probably shouldn\'t make room){}'
    }
    },
    cost = 1,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            if SMODS.pseudorandom_probability(card, 'group_0_a6027846', 1, card.ability.extra.odds, 'c_rolatro_petsimulator99', true) then
                
                G.E_MANAGER:add_event(Event({
                  trigger = 'after',
                  delay = 0.4,
                  func = function()
                      play_sound('timpani')
                      local new_joker = SMODS.add_card({ set = 'Joker', key = 'j_rolatro_hugejokerpet' })
                      if new_joker then
                      end
                      used_card:juice_up(0.3, 0.5)
                      return true
                  end
              }))
              delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}