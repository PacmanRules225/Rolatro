SMODS.Consumable {
    key = 'frontpage',
    set = 'Tarot',
    pos = { x = 3, y = 0 },
    config = { extra = {
        
        consumable_count = 1
    } },
    loc_txt = {
        name = 'Front Page',
        text = {
        [1] = 'Creates a random {C:attention}Experience{} card',
        [2] = '{C:inactive}(Must have room){}'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            for i = 1, math.min(1, G.consumeables.config.card_limit - #G.consumeables.cards) do
            G.E_MANAGER:add_event(Event({
            trigger = 'after',
            delay = 0.4,
            func = function()
            play_sound('timpani')
            SMODS.add_card({ set = experience, })                            
            used_card:juice_up(0.3, 0.5)
            return true
        end
        }))
    end
    delay(0.6)
    end,
    can_use = function(self, card)
        return true
    end
}